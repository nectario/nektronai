# NektronAI website refresh (static)

This is a lightweight, no-build-step site refresh intended to feel:
- Minimal and sophisticated
- Technical / scientist-friendly
- Fast (pure HTML/CSS + a tiny JS file)

## Files
- `index.html` – landing page
- `grownet.html` – dedicated GrowNet research page (includes explicit "in development" note)
- `privacy.html`, `terms.html`, `support.html` – styled legal/support pages
- `assets/styles.css` – theme + layout
- `assets/site.js` – theme toggle + mobile nav
- `assets/favicon.svg` – simple favicon

## Local preview
Open `index.html` in a browser.

## Deploy
Upload the folder contents to your static host (S3/Cloudflare Pages/GitHub Pages/etc.).

## Quick customization
- Replace the mark in `assets/favicon.svg` and the inline SVG in the header/footer (search for `gmark`) once your logo is finalized.
- Update product descriptions in `index.html` if you want different positioning.
- Update the GrowNet page copy as research milestones become public.

