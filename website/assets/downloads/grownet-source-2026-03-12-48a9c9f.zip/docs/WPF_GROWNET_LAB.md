# WPF GrowNet Lab

The WPF GrowNet Lab is a Windows desktop shell for GrowNet experimentation.

It is not a replacement for the CLI. It is a polished orchestration layer over the existing runtime entry points, schedule files, trace streams, and benchmark outputs.

## Purpose

The lab exists to make GrowNet feel like a research workstation:

- dark, high-signal UI
- keyboard-first Morse and temporal probing
- one shell for Python, Java, and Mojo
- shared schedule load, save, replay, and jitter workflows
- trace and benchmark visibility without leaving the desktop

## Install Model

The GrowNet Lab installer ships the **desktop app only**.

It does **not** install the full GrowNet source repository. Instead, on first launch the app asks for a local GrowNet source root and validates that it contains the runtime-side files the adapters need, such as:

- `grownet.sh`
- `experiments/`
- `src/python/`

This keeps the installed app separate from the source distribution:

- source code remains in Git
- the lab app remains updateable as a product
- runtime adapters stay pointed at the repo/worktree you actually want to use

## Architecture

The app is intentionally split into:

- `tools/GrowNetLab/app/GrowNetLab.App`
  - WPF shell, theme resources, views, and Windows title-bar polish
- `tools/GrowNetLab/core/GrowNetLab.Core`
  - runtime adapters
  - temporal schedule load/save/jitter services
  - process orchestration
  - Morse-first lab view model
- `tools/GrowNetLab/tests/GrowNetLab.Tests`
  - adapter, parser, schedule, and view-model tests

The desktop app talks to GrowNet through the existing launcher surface:

- `./grownet.sh`
- config files
- shared temporal schedule files
- JSONL trace output
- JSONL benchmark output

That keeps the lab front-end language-independent.

The configured GrowNet source root is persisted in local user settings, so the app reuses it across launches.

## Runtime Adapters

The lab currently includes:

- `PythonRuntimeAdapter`
- `JavaRuntimeAdapter`
- `MojoRuntimeAdapter`

These adapters build the correct CLI command shape for:

- interactive scripted sessions
- replay sessions
- trace runs
- benchmark runs

The current WPF shell is Morse-first.

The adapters resolve all runtime paths relative to the configured GrowNet source root, which is why the installer does not need to bundle the repository itself.

Profile support in the current WPF lab:

- Python: `morse_probe`
- Java: `morse_probe`
- Mojo: `morse_probe`

The adapter layer is intentionally written so broader profile support can be added later without redesigning the shell.

## Theme Direction

The lab reuses the InterviewHelperAI dark-theme language conceptually:

- dark neutral surfaces
- layered cards
- muted secondary text
- restrained accent usage
- immersive dark title-bar treatment
- technical, JetBrains-like tone instead of default-WPF chrome

This is intentionally a shared NektronAI internal design direction, not InterviewHelperAI branding.

## Morse-First Scope

V1 is centered on the Morse temporal slice:

- choose Python, Java, or Mojo
- run interactive, replay, trace, or benchmark flows
- save recorded schedules
- replay shared schedules
- apply deterministic jitter before replay
- inspect live summaries, trace events, and benchmark results

For interactive live behavior, the WPF shell owns the keyboard semantics and cadence timer, then drives the runtime through the existing scripted session interface. That keeps the UI consistent across languages while still preserving the raw temporal model.

## Shared Temporal Schedule Support

The lab reads and writes the shared temporal schedule format described in:

- [TEMPORAL_SIGNAL_SCHEDULES.md](/C:/Development/Projects/GrowNet/docs/TEMPORAL_SIGNAL_SCHEDULES.md)

This is the main cross-language bridge for:

- record
- replay
- jitter
- parity-oriented workflows

## Installer Workflow

Installer assets live under:

- [installer](/C:/Development/Projects/GrowNet/installer)

The installer flow is:

1. publish the WPF app
2. build the MSI and bootstrapper
3. install the lab app
4. select a GrowNet source root on first launch
5. run Python, Java, and Mojo through the existing CLI/runtime surfaces

## Current Limitations

V1 intentionally does not include:

- 2D editor
- 3D editor
- Blender integration
- full internal graph visualization
- native per-language embedded runtimes

The desktop app orchestrates runtimes through the CLI instead of embedding Python, Java, or Mojo logic directly.

## Future Expansion Path

The current structure leaves room for:

- image-sequence temporal labs
- one-frame-per-tick experiments
- richer trace visualizers
- 2D and later 3D experimental panels
- deeper runtime settings and environment management
