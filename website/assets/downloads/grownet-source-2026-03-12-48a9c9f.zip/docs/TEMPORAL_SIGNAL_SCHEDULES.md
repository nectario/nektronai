# TEMPORAL_SIGNAL_SCHEDULES.md

GrowNet now uses a shared temporal schedule format across Python, Java, and Mojo for live capture, deterministic replay, jittered replay, and replay-based parity tests.

## Why This Exists

Live timing and replay solve different problems.

- live capture preserves real human timing imperfections
- replay gives us deterministic reproduction
- jittered replay lets us perturb raw timing structure without adding symbolic labels
- replay is the stable cross-language parity surface

This framework is generic. It is useful for:

- Morse-style pulse experiments
- raw pulse trains
- rhythm studies
- temporal novelty experiments
- event streams
- future frame-per-tick inputs

It does **not** classify timing into symbols outside GrowNet.

## Shared JSON Format

Current shared format:

```json
{
  "name": "morse_probe_capture",
  "tick_ms": 50,
  "ports": ["signal"],
  "ticks": [
    {"index": 0, "values": {"signal": 1.0}},
    {"index": 1, "values": {"signal": 1.0}},
    {"index": 2, "values": {"signal": 0.0}},
    {"index": 3, "values": {"signal": 0.0}}
  ],
  "metadata": {
    "profile": "morse_probe"
  }
}
```

Fields:

- `name`: schedule name
- `tick_ms`: cadence metadata for one tick
- `ports`: ordered scalar port list
- `ticks`: one raw value map per tick
- `metadata`: optional descriptive fields only

V1 scope is scalar-per-port schedules. That keeps the format simple while leaving room for later extensions.

## Current Files

Checked-in examples:

- [morse_raw_schedule.json](C:/Development/Projects/GrowNet/experiments/morse_raw_schedule.json)
- [morse_temporal_schedule.json](C:/Development/Projects/GrowNet/experiments/morse_temporal_schedule.json)

Compatibility note:

- the older Morse experiment config shape is still supported
- the shared temporal schedule shape is the forward-looking replay/record format

## CLI Flags

Shared temporal flags:

- `--record-schedule path/to/schedule.json`
- `--replay-schedule path/to/schedule.json`
- `--jitter-ms 10`
- `--jitter-pct 0.10`
- `--jitter-seed 0`
- `--interactive-mode scripted|live|replay`

## Record / Replay Flow

Typical workflow:

1. run a live session and record the raw schedule
2. replay that exact schedule in Python, Java, or Mojo
3. optionally apply deterministic jitter
4. compare trace or summary behavior on the replayed schedule

Examples:

```bash
./grownet.sh --lang python --interactive --profile morse_probe --interactive-mode live --record-schedule out/live_capture.json
./grownet.sh --lang java --interactive --profile morse_probe --interactive-mode live --record-schedule out/java_capture.json
./grownet.sh --lang mojo --interactive --profile morse_probe --interactive-mode live --record-schedule out/mojo_capture.json

./grownet.sh --lang python --interactive --profile morse_probe --interactive-mode replay --replay-schedule out/live_capture.json
./grownet.sh --lang java --interactive --profile morse_probe --interactive-mode replay --replay-schedule out/live_capture.json
./grownet.sh --lang mojo --interactive --profile morse_probe --interactive-mode replay --replay-schedule out/live_capture.json
```

## Jittered Replay

Jitter operates on raw temporal runs, not symbolic units.

Examples:

```bash
./grownet.sh --lang python --interactive --profile morse_probe --interactive-mode replay --replay-schedule out/live_capture.json --jitter-ms 10 --jitter-seed 7
./grownet.sh --lang java --config experiments/morse_raw_schedule.json --replay-schedule out/live_capture.json --jitter-pct 0.10 --jitter-seed 7
./grownet.sh --lang mojo --benchmark --replay-schedule out/live_capture.json --jitter-ms 10 --jitter-seed 7
```

Current jitter rules:

- jitter stretches or shortens runs of equal raw values
- it never introduces symbolic labels
- with a fixed seed, the jittered schedule is deterministic

## Live vs Scripted vs Replay

- `scripted`: manual one-tick stepping
- `live`: cadence loop running on wall-clock time
- `replay`: deterministic schedule playback

All three remain useful:

- `scripted` is debugger-friendly
- `live` captures real timing behavior
- `replay` is the parity bridge

## Live Signal Controls

The shared live temporal model now distinguishes:

- one-shot pulse
- sustained high
- sustained low

Recommended live key map across Python, Java, and Mojo Morse sessions:

- `space` = one-shot pulse for the current cadence window only
- `1` = latch sustained high until changed
- `0` = latch sustained low until changed
- `r` = reset
- `s` = summary
- `t` = toggle output mode
- `c` = clear/reprint panel
- `h` = help
- `q` = quit

Effective signal rule for each cadence window:

- if a one-shot pulse was seen in the current window, emit `1.0`
- otherwise if sustained-high is active, emit `1.0`
- otherwise emit `0.0`

Reset rule:

- reset clears the recorded schedule accumulated so far
- reset clears any pending pulse in the current cadence window
- reset clears sustained state back to low
- the first post-reset tick is low unless new high input is explicitly provided after the reset

## Language Notes

Python:

- richest live Morse probing path
- records and replays shared schedules directly

Java:

- supports scripted, live, and replay Morse sessions
- uses real terminal key typing when available and portable fallback elsewhere
- records and replays shared schedules directly

Mojo:

- supports scripted, live, and replay through the host-managed Morse launcher
- live reset now clears both schedule history and pending cadence-window state
- schedule files are first-class, even though current terminal interaction is intentionally simple

## Parity Guidance

Wall-clock live sessions are not the parity surface.

Correct parity method:

1. capture or author a schedule
2. replay it in each language
3. compare the stable semantic surface

That keeps parity deterministic without erasing real human timing from the experimentation workflow.
