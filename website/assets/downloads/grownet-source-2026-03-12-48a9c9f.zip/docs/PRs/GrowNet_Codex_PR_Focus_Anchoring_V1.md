# PR: Focus & Anchoring V1 for GrowNet (Python-First), Plus Adjacent Runtime Verification

## Title

focus: add first-class Focus & Anchoring V1, serial focus policies, anchor maps, trace/config integration, and verify adjacent stale runtime surfaces

---

## Summary

This PR turns **focus and anchoring** into first-class runtime concepts in GrowNet.

Right now, the exposed Python runtime already has a meaningful **anchoring substrate**:

- scalar slot routing depends on the relationship between the current input and the previous input
- slot policies compute bins from percent-delta relative to `last_input`
- `SlotEngine` selects bins/slots from that anchor-like reference
- the 2D input path exists, but the currently surfaced implementation still scans every pixel in raster order rather than running a real serial focus policy over candidate points

So GrowNet already has **anchor-relative routing**, but not yet a true **focus engine**.

This PR should add a Python-first **Focus & Anchoring V1** that introduces:

- first-class focus candidates
- serial focus selection
- anchor state and anchor maps
- pluggable focus policies
- trace events for focus/anchor behavior
- config support for focus policies
- interactive hooks so focus can be observed live

At the same time, because the currently exposed code surface still shows a few older-looking runtime issues, this PR should also **verify and fix adjacent stale surfaces only if they are still present on HEAD**.

---

## Important note about repository state

The currently exposed code search surface shows a few Python files that may be older than the latest branch history discussed elsewhere.

That means:

- do **not** blindly re-apply older cleanup changes if they are already fixed on current HEAD
- first verify whether the issue still exists in the live checked-out code before changing it

This matters especially for things like:
- placeholder `delivered_events`
- `Synapse.deliver()` / `Neuron.fire()` contract drift
- demos indexing `RegionMetrics` like a dict
- `train_omniglot.py` using module-global CLI args

If those are already fixed on current HEAD, leave them alone.

---

## Repository-grounded current assessment

Based on the currently exposed repository code surface:

### What already exists

1. `Neuron` stores `have_last_input` and `last_input_value`, which means scalar routing already has anchor-like state.
2. `SlotPolicy.compute_slot_id(last_input, current_input)` expresses slot choice relative to a previous input.
3. `SlotEngine.select_or_create_slot()` computes slot bins from percent-delta relative to `last_input_value`.
4. `InputLayer2D.forward_image()` currently scans all pixels in raster order and feeds them one by one.

### What does not yet exist as a first-class runtime concept

1. `FocusCandidate`
2. `FocusPolicy`
3. `FocusEngine`
4. `AnchorMap`
5. serial focus scheduling over multiple candidate points
6. focus-specific trace events
7. focus-specific config controls

### What likely still needs verification/fix if present on HEAD

1. placeholder delivered-event accounting
2. muddy `Synapse.deliver()` / `Neuron.fire()` contract
3. demos using dict-style `RegionMetrics`
4. `train_omniglot.py` depending on module-global `args`

---

## Architectural rule

Respect GrowNet's language-reference model:

- **Java** = core semantic / architectural reference
- **Python** = Python-language-style reference
- **Mojo** should track Python almost one-to-one
- **C++** follows Java as much as practical

For this PR:

- implement **Focus & Anchoring V1 in Python first**
- keep Python explicit and readable
- do **not** force Python to look Java-like
- structure the code so Mojo can later mirror the Python implementation closely

---

## Required reading before coding

Read these before implementation:

1. `docs/READ_ORDER.md`
2. `docs/LANGUAGE_REFERENCE_POLICY.md`
3. `docs/CODING_STYLE_MUST_READ.md`
4. `docs/GOLDEN_RULE.md`
5. `docs/GROWTH.md`
6. `docs/CREATION_AND_GROWTH_POINTS.md`
7. `docs/contracts/grownet.contract.v5.json`
8. `docs/GrowNet_Design_Spec_V5.md`
9. `docs/TRACE_RUNNER.md`
10. `docs/TRACE_PARITY.md`
11. `docs/PARITY_DECISION_CHECKLIST.md`
12. `docs/INTERACTIVE_RUNNER.md`
13. `docs/EXPERIMENT_RUNNER.md`
14. `docs/BENCHMARK_RUNNER.md`

---

## Coding style requirements

These are mandatory:

- Follow `docs/CODING_STYLE_MUST_READ.md`
- No single- or double-character identifiers anywhere, including loops
- Keep Python explicit and readable
- Avoid clever one-liners
- Preserve determinism
- Preserve two-phase tick discipline
- Do not introduce speculative redesigns
- Do not change runtime semantics just to make focus easier to implement
- Prefer small helper modules over giant files

---

## Scope

### Implement in this PR

1. Python-first first-class Focus & Anchoring runtime layer
2. serial focus candidate selection
3. anchor state and anchor-map support
4. pluggable focus policies
5. focus-aware 2D scene handling
6. focus trace events and schema updates
7. focus config support for experiment and interactive runners
8. interactive visibility hooks for focus behavior
9. verify/fix adjacent stale Python runtime surfaces if still present on HEAD
10. docs and tests

### Do not implement in this PR

- Java full focus runtime unless trivial and clearly needed
- Mojo focus runtime
- C++ focus runtime
- mechanical/overt focus for robotics/body movement
- Blender integration
- image/audio ingestion redesign
- speculative world-model redesign
- broad unrelated cleanup not tied to focus/anchoring or explicitly verified stale surfaces

---

# Phase 1 — introduce first-class runtime concepts

## 1. Add first-class focus/anchor data structures in Python

Create a small, explicit focus package, for example:

```text
src/python/focus/
    __init__.py
    focus_types.py
    focus_policy.py
    focus_engine.py
    anchor_map.py
```

### Core runtime concepts to introduce

- `FocusCandidate`
  - represents a candidate focus point/location
  - carries score components such as energy / novelty / familiarity / optional task bias

- `FocusSelection`
  - represents the chosen active focus for a tick or substep

- `AnchorState`
  - current active reference point

- `AnchorMap`
  - remembered meaningful locations / reference points

- `FocusPolicy`
  - pluggable strategy for choosing the next focus candidate

- `FocusEngine`
  - produces candidates, chooses active focus, updates anchors, and returns focus metadata used by routing

### Important

Keep these objects small and explicit.
Do not over-generalize them.

---

# Phase 2 — scalar anchoring formalization

## 2. Formalize scalar anchoring rather than leaving it implicit

Right now scalar anchoring appears to live implicitly through `last_input_value` and percent-delta binning.

Refactor this so the runtime is explicit about:

- scalar current anchor
- scalar anchor update rule
- scalar distance-from-anchor
- scalar focus/anchor metadata passed into slot routing

### Important

Do **not** break existing scalar behavior unless the current behavior is clearly a bug.
The goal is to make the anchoring concept first-class and inspectable.

---

# Phase 3 — 2D focus engine

## 3. Replace raster-scan-only 2D processing with candidate-driven serial focus

The currently surfaced 2D path iterates over all pixels in raster order.
That is not the richer GrowNet focus model.

Implement a Python-first 2D focus flow like:

```text
frame
-> generate focus candidates
-> select one active focus point
-> update anchor / anchor map
-> route local input relative to that active focus
-> optionally continue serially through remaining candidates
```

### Important design decision

Focus is **serial**, not simultaneous.

If multiple salient points exist:
- produce multiple candidates
- choose one according to the policy
- process serially
- preserve remembered points in the anchor map

### Required first implementation

For V1, support sparse / salient 2D inputs well.
Do not try to solve all dense-scene complexity immediately.

---

# Phase 4 — pluggable focus policies

## 4. Implement at least these focus policies

### `energy_first`
Pick the highest-energy candidate first.

### `random_candidate`
Pick randomly among candidate points (deterministically if seed-controlled).

### `sequential_scan`
Pick in scan/raster order or deterministic spatial order.

### `novelty_first`
Prefer the candidate farthest from current anchor / least explained by current anchor map.

### `familiarity_first`
Prefer candidates closest to remembered anchors or historically reinforced points.

### Important

You do not need to make all of these equally sophisticated on day one.
But they should exist as real named policies with deterministic behavior.

---

# Phase 5 — inhibition of immediate revisit

## 5. Add lightweight inhibition-of-return support

To avoid repeatedly selecting the same strongest point over and over, implement a small deterministic inhibition mechanism.

### Example

A candidate that was just focused may receive a temporary penalty for a few ticks/substeps.

This can be simple, but it should exist.
It will be very useful for multi-point scenes.

---

# Phase 6 — anchor map

## 6. Add an anchor-map concept

A single active anchor is not enough for the multi-point behavior you described.

Add an `AnchorMap` that can:

- remember recently meaningful points
- create anchors when a point matters enough
- update anchors when revisited
- expire or decay anchors if unused for long periods

### Keep V1 simple

This does not need to be a giant spatial memory system.
A small deterministic remembered set is enough for V1.

---

# Phase 7 — integrate focus with slot routing

## 7. Make slot selection explicitly relative to active focus/anchor

Once a focus point is selected, slot routing should happen relative to that active reference.

This means the routing path should be able to access:

- active focus point
- current anchor
- distance from anchor
- selected policy name
- whether this point is novel vs familiar relative to anchor map

### Important

Slot selection and focus selection are **not** the same thing.

Focus selection answers:
- what are we looking at now?

Slot selection answers:
- where does this focused input land inside the neuron's memory structure?

Keep those concepts separate.

---

# Phase 8 — trace and schema support

## 8. Extend the trace system with focus-specific events

Add trace families/events such as:

```text
focus.candidates
focus.select
focus.shift
anchor.create
anchor.update
anchor.revisit
focus.return_inhibited
```

### Suggested fields

Use fields like:

- `candidate_count`
- `focus_policy`
- `focus_point`
- `anchor_before`
- `anchor_after`
- `distance_from_anchor`
- `candidate_energy`
- `candidate_novelty`
- `candidate_familiarity`
- `selected_rank`
- `inhibited`

### Important

Update the shared trace schema and docs if focus events become part of the supported event vocabulary.

---

# Phase 9 — config support

## 9. Add focus controls to experiment configs

Extend experiment config support with a `focus` block like:

```json
{
  "focus": {
    "policy": "energy_first",
    "serial": true,
    "candidate_limit": 8,
    "allow_anchor_map": true,
    "inhibition_of_return_ticks": 3
  }
}
```

### Important

This should work naturally with:
- batch run mode
- trace mode
- benchmark mode
- interactive mode

---

# Phase 10 — interactive hooks

## 10. Make interactive mode able to reveal focus behavior

Interactive mode is the best place to make focus visible.

Add support so interactive sessions can show:
- current focus policy
- active focus point
- anchor state
- anchor-map size / summary
- selected candidate order for sparse 2D scenes where relevant

### Important

Do not build a giant TUI.
Simple compact/verbose output is enough.

### Examples of useful compact output additions

```text
tick=12 policy=energy_first focus=(7,12) anchor=(7,12) anchor_count=3 fired=true delivered=1
```

---

# Phase 11 — verify adjacent stale runtime surfaces

## 11. Before changing adjacent runtime issues, verify they still exist on HEAD

The currently exposed repo surface still shows some older-looking runtime issues.

For each of the following, first verify whether it still exists on the actual checked-out HEAD:

- placeholder `delivered_events`
- `Synapse.deliver()` / `Neuron.fire()` contract mismatch
- demos indexing `RegionMetrics` like a dict
- `train_omniglot.py` depending on global `args`

### Rule

If the issue still exists:
- fix it in this PR if it meaningfully supports focus/anchoring work or keeps adjacent runtime behavior honest

If the issue is already fixed:
- do nothing
- do not reintroduce churn

### Why this belongs here

A focus/anchoring PR should not sit on top of obviously misleading runtime surfaces if they still remain.

---

# Phase 12 — docs

## 12. Add a dedicated focus doc

Create:

```text
docs/FOCUS_AND_ANCHORING.md
```

It should define:

- focus point
- anchor
- anchor map
- serial focus
- covert/field focus
- overt/mechanical focus (future concept)
- focus policy
- relation between focus and slot routing

### Important

Be explicit that:
- focus is serial, not simultaneous
- multiple candidates may exist at once, but one active focus is selected at a time
- GrowNet focus is not transformer attention

## 13. Update related docs

Update:
- `docs/TRACE_RUNNER.md`
- `docs/INTERACTIVE_RUNNER.md`
- `docs/EXPERIMENT_RUNNER.md`
- `docs/GrowNet_Design_Spec_V5.md` if needed
- any journal/spec docs if they live in-repo and are meant to stay current

---

# Phase 13 — tests

## 14. Add focused tests

At minimum, add/update tests for:

- scalar anchor-state behavior
- candidate generation for sparse 2D frames
- each focus policy returns deterministic selection
- anchor-map create/update/revisit behavior
- inhibition-of-return behavior
- slot routing relative to active focus
- focus trace output shape
- config parsing for the `focus` block
- interactive session focus summary behavior

### Important

Do not write fragile tests that depend on a real terminal or giant images.
Use small deterministic fixtures.

---

# Phase 14 — honesty about future work

## 15. Explicitly keep overt/mechanical focus as future work

You and the docs distinguish between:

- covert / field focus
- overt / mechanical focus

This PR should implement covert/field focus only.

### Do not fake overt focus

No camera/body/head simulation is required in this PR.
That belongs to a later robotics/agent phase.

---

## Acceptance criteria

This PR is complete when:

1. Python has a first-class `FocusEngine` / equivalent runtime layer
2. scalar anchoring is explicit rather than only implicit
3. 2D focus can operate on candidate points instead of only raster scan
4. focus policies exist:
   - `energy_first`
   - `random_candidate`
   - `sequential_scan`
   - `novelty_first`
   - `familiarity_first`
5. an `AnchorMap` or equivalent remembered-point structure exists
6. focus affects routing before slot selection
7. trace events exist for focus / anchor behavior
8. configs can specify focus policy / settings
9. interactive mode can surface focus behavior
10. adjacent stale runtime issues are fixed **only if they still exist on HEAD**
11. docs explain focus and anchoring clearly
12. tests cover the new behavior

---

## Explicit non-goals

Do not do these in this PR:

- Java full focus runtime
- Mojo full focus runtime
- C++ full focus runtime
- overt/mechanical focus
- Blender integration
- giant TUI
- image/audio ingestion redesign
- broad unrelated runtime cleanup beyond verified adjacent stale surfaces

---

## Suggested commit structure

1. add focus runtime types and scalar anchoring formalization
2. add 2D candidate generation and focus policies
3. add anchor map and inhibition-of-return
4. add trace/config/interactive integration
5. verify/fix adjacent stale surfaces if still present
6. add docs and tests

---

## Final response expected from Codex

At the end, provide:

1. summary of what changed
2. files changed
3. which focus concepts are now first-class
4. supported focus policies
5. how anchor maps behave
6. how focus is exposed in trace/config/interactive mode
7. which adjacent stale issues were still present on HEAD and were fixed
8. tests run
9. what remains for future overt/mechanical focus
