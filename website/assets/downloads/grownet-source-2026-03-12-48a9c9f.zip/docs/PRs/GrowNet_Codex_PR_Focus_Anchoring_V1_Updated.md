# PR: Focus & Anchoring V1 for GrowNet (Python-First), Updated for Current Main

## Title

focus: add first-class Focus & Anchoring V1 on top of the current Python runtime, trace, interactive, and experiment-runner stack

---

## Summary

This PR is an updated **Focus & Anchoring V1** handoff based on the **current GrowNet codebase**.

The repo has already moved well beyond the earlier stale code snapshot. In particular, the following are already present on `main` and should be treated as the baseline, not re-implemented:

- real Python `delivered_events` accounting
- normalized `Synapse.deliver()` / `Neuron.fire()` delivery contract
- cleaned demos using the real `RegionMetrics` object API
- `tick_image()` as a compatibility alias for the real `tick_2d()` path
- benchmark mode
- interactive mode
- config-driven experiment runner
- existing spatial focus / temporal anchoring substrate
- existing focus-related docs such as:
  - `docs/SPATIAL_FOCUS.md`
  - `docs/2D_Bins_Spatial_Focus.md`
  - `docs/FOCUS_AND_GROWTH_CHEATSHEET.md`

So this PR should **not** spend time re-fixing older runtime/demo cleanup issues unless a fresh code review of current HEAD proves something is still broken.

Instead, this PR should build the next layer:

> **turn anchoring into an explicit first-class runtime concept and add a real serial focus engine for candidate selection, anchor maps, trace integration, config controls, and interactive visibility.**

---

## Current codebase assessment (updated)

### Already present and should be preserved

The current Python runtime already has a meaningful **anchoring substrate**:

- `Neuron` keeps temporal focus state:
  - `focus_anchor`
  - `focus_set`
  - `focus_anchor_row`
  - `focus_anchor_col`
- `SlotConfig` already exposes:
  - `anchor_mode`
  - `bin_width_pct`
  - `row_bin_width_pct`
  - `col_bin_width_pct`
  - `spatial_enabled`
- `SlotEngine` already performs:
  - scalar binning relative to a scalar anchor
  - 2D binning relative to `(row, col)` anchors
  - fallback tracking / missing-slot tracking
- `Region` already supports:
  - `tick_inputs(...)`
  - `tick_2d(...)`
  - `tick_nd(...)`
  - interactive mode
  - config-driven experiments
- Existing tests already cover:
  - temporal focus basics
  - spatial slotting basics
  - delivery metrics
  - trace runner
  - interactive runner
  - experiment runner

### What is still missing

What is **not yet first-class** in the current codebase:

1. a dedicated `FocusEngine`
2. an explicit `FocusCandidate`
3. pluggable **focus policies** as runtime objects
4. a multi-point `AnchorMap`
5. serial focus selection over multiple candidates
6. focus-specific trace events
7. a dedicated `focus` block in experiment configs
8. interactive visualization of focus/anchor behavior
9. a clean distinction between:
   - current active focus point
   - active anchor/reference
   - remembered anchor map

### Important nuance

The current `tick_2d()` path is already honest and per-pixel.

That means this PR must **not** silently replace current `tick_2d()` semantics in a breaking way.

Instead, Focus & Anchoring V1 should be added as an **optional focus-aware layer** on top of the current 2D runtime path.

---

## Important architectural rule

Respect GrowNet's language-reference model:

- **Java** = core semantic / architectural reference
- **Python** = Python-language-style reference
- **Mojo** should track Python almost one-to-one
- **C++** follows Java as much as practical

For this PR:

- implement **Focus & Anchoring V1 in Python first**
- keep Python explicit and readable
- do **not** force Python to look Java-like
- structure the code so Mojo can later mirror the Python implementation closely

---

## Required reading before coding

Read these before implementation:

1. `docs/READ_ORDER.md`
2. `docs/LANGUAGE_REFERENCE_POLICY.md`
3. `docs/CODING_STYLE_MUST_READ.md`
4. `docs/GOLDEN_RULE.md`
5. `docs/GROWTH.md`
6. `docs/CREATION_AND_GROWTH_POINTS.md`
7. `docs/contracts/grownet.contract.v5.json`
8. `docs/GrowNet_Design_Spec_V5.md`
9. `docs/SPATIAL_FOCUS.md`
10. `docs/2D_Bins_Spatial_Focus.md`
11. `docs/FOCUS_AND_GROWTH_CHEATSHEET.md`
12. `docs/TRACE_RUNNER.md`
13. `docs/TRACE_PARITY.md`
14. `docs/PARITY_DECISION_CHECKLIST.md`
15. `docs/INTERACTIVE_RUNNER.md`
16. `docs/EXPERIMENT_RUNNER.md`
17. `docs/BENCHMARK_RUNNER.md`

Also review the existing focus-related tests before designing new ones:
- `src/python/tests/test_temporal_focus.py`
- `src/python/tests/test_spatial_focus.py`
- `src/python/tests/test_trace_runner_followup.py`
- current interactive / experiment runner tests

---

## Coding style requirements

These are mandatory:

- Follow `docs/CODING_STYLE_MUST_READ.md`
- No single- or double-character identifiers anywhere, including loops
- Keep Python explicit and readable
- Avoid clever one-liners
- Preserve determinism
- Preserve two-phase tick discipline
- Do not introduce speculative redesigns
- Do not change existing non-focus runtime semantics just to make focus easier
- Prefer small helper modules over giant files

---

## Scope

### Implement in this PR

1. Python-first first-class Focus & Anchoring runtime layer
2. serial focus candidate selection
3. anchor state and anchor-map support
4. pluggable focus policies
5. optional focus-aware 2D scene handling
6. focus trace events and schema updates
7. focus config support for experiment and interactive runners
8. interactive visibility hooks for focus behavior
9. cleanup of the currently misleading `anchor_mode` surface if needed
10. docs and tests

### Do not implement in this PR

- Java full focus runtime unless trivial and clearly needed
- Mojo focus runtime
- C++ focus runtime
- overt/mechanical focus for robotics/body movement
- Blender integration
- image/audio ingestion redesign
- speculative world-model redesign
- broad unrelated cleanup already handled in earlier PRs

---

# Phase 1 — introduce first-class runtime concepts

## 1. Add first-class focus/anchor data structures in Python

Create a small, explicit focus package, for example:

```text
src/python/focus/
    __init__.py
    focus_types.py
    focus_policy.py
    focus_engine.py
    anchor_map.py
```

### Core runtime concepts to introduce

- `FocusCandidate`
  - candidate point/location
  - may include:
    - location
    - energy
    - novelty score
    - familiarity score
    - task bias
    - last-visited penalty

- `FocusSelection`
  - chosen active focus point for the current tick/substep

- `AnchorState`
  - current active anchor/reference

- `AnchorMap`
  - remembered meaningful points or reference locations

- `FocusPolicy`
  - pluggable strategy for choosing the next focus candidate

- `FocusEngine`
  - produces candidates, chooses active focus, updates anchors, and returns focus metadata used by routing

### Important

Keep these objects small and explicit.
Do not over-generalize them.

---

# Phase 2 — formalize what already exists

## 2. Make scalar anchoring explicit without breaking current behavior

Right now scalar anchoring exists implicitly through:
- `focus_anchor`
- `focus_set`
- percent-delta binning in `SlotEngine`

Refactor so the runtime is explicit about:

- scalar anchor state
- scalar distance-from-anchor
- scalar anchor update rule
- scalar focus metadata passed into routing / slot selection

### Important

Do **not** break existing scalar behavior unless current behavior is clearly wrong.
This should mostly be a **formalization / exposure** pass.

## 3. Clarify or correct the current `anchor_mode` surface

The current Python surface advertises more anchor modes in `SlotConfig` than the runtime fully implements cleanly.

Review current code/docs/contract and do one of the following:

### Preferred
Keep the supported modes explicit and truthful for V1.

Examples:
- scalar: `FIRST` only unless more are genuinely implemented
- spatial: `FIRST` and `ORIGIN`

### Or
Implement the missing anchor modes if they are small and truly ready.

### Important

Do not leave `anchor_mode` looking more complete than it actually is.

---

# Phase 3 — 2D focus engine as an optional layer, not a breaking rewrite

## 4. Add a focus-aware 2D path without breaking existing `tick_2d()`

The current `tick_2d()` path is already real and per-pixel.

Do **not** silently replace its semantics in a way that breaks existing tests and demos.

### Preferred design

Keep the current baseline 2D path intact when focus is **not enabled**.

Add an optional focused mode such as:
- `Region.tick_2d_focused(...)`
- or a `focus.enabled` config path that causes the runner to choose a focus-aware path

### Focus-aware 2D flow

```text
frame
-> generate focus candidates
-> select one active focus point
-> update anchor / anchor map
-> route local input relative to that active focus
-> optionally continue serially through remaining candidates
```

### Important design decision

Focus is **serial**, not simultaneous.

If multiple salient points exist:
- produce multiple candidates
- choose one according to the policy
- process serially
- preserve remembered points in the anchor map

### Required V1 implementation

Support sparse / salient 2D inputs well first.
Do not try to solve every dense-scene case immediately.

---

# Phase 4 — pluggable focus policies

## 5. Implement at least these focus policies

### `energy_first`
Pick the highest-energy candidate first.

### `random_candidate`
Pick randomly among candidate points using deterministic region RNG / seed control.

### `sequential_scan`
Pick in scan/raster order or deterministic spatial order.

### `novelty_first`
Prefer the candidate least explained by the current anchor / anchor map.

### `familiarity_first`
Prefer candidates closest to remembered anchors or historically reinforced points.

### Important

These do not all need to be equally sophisticated on day one.
But they should exist as real named policies with deterministic behavior.

---

# Phase 5 — inhibition of immediate revisit

## 6. Add lightweight inhibition-of-return support

To avoid repeatedly selecting the strongest point over and over, implement a small deterministic inhibition mechanism.

### Example

A candidate that was just focused may receive a temporary penalty for a few ticks/substeps.

This can be simple, but it should exist for V1.
It is important for multi-point scenes.

---

# Phase 6 — anchor map

## 7. Add an anchor-map concept

A single active anchor is not enough for the multi-point behavior described in the docs and discussion.

Add an `AnchorMap` that can:

- remember recently meaningful points
- create anchors when a point matters enough
- update anchors when revisited
- expire or decay anchors if unused for long periods

### Keep V1 simple

This does not need to be a giant spatial memory system.
A small deterministic remembered set is enough for V1.

---

# Phase 7 — integrate focus with slot routing

## 8. Make slot selection explicitly relative to active focus/anchor

Once a focus point is selected, slot routing should happen relative to that active reference.

This means routing should be able to access:

- active focus point
- current anchor
- distance from anchor
- selected policy name
- novelty/familiarity metadata if available

### Important

Slot selection and focus selection are **not** the same thing.

- focus selection answers: what point are we looking at now?
- slot selection answers: where does this focused input land inside the neuron's memory structure?

Keep those concepts separate.

---

# Phase 8 — trace and schema support

## 9. Extend the trace system with focus-specific events

Add trace families/events such as:

```text
focus.candidates
focus.select
focus.shift
anchor.create
anchor.update
anchor.revisit
focus.return_inhibited
```

### Suggested fields

Use fields like:

- `candidate_count`
- `focus_policy`
- `focus_point`
- `anchor_before`
- `anchor_after`
- `distance_from_anchor`
- `candidate_energy`
- `candidate_novelty`
- `candidate_familiarity`
- `selected_rank`
- `inhibited`

### Important

Update the shared trace schema and docs if focus events become part of the supported event vocabulary.

---

# Phase 9 — config support

## 10. Add focus controls to experiment configs

Extend experiment config support with a `focus` block like:

```json
{
  "focus": {
    "enabled": true,
    "policy": "energy_first",
    "serial": true,
    "candidate_limit": 8,
    "allow_anchor_map": true,
    "inhibition_of_return_ticks": 3
  }
}
```

### Important

This should work naturally with:
- batch run mode
- trace mode
- benchmark mode
- interactive mode

---

# Phase 10 — interactive hooks

## 11. Make interactive mode able to reveal focus behavior

Interactive mode is the best place to make focus visible.

Add support so interactive sessions can show:
- current focus policy
- active focus point
- current anchor
- anchor-map summary
- focus order for sparse 2D scenes where relevant

### Important

Do not build a giant TUI.
Simple compact/verbose output is enough.

### Examples of useful compact output additions

```text
tick=12 policy=energy_first focus=(7,12) anchor=(7,12) anchor_count=3 fired=true delivered=1
```

### Optional but good
If implementation quality supports it, add a provisional `grid_2d_focus` interactive profile.
If not, leave it for later.

---

# Phase 11 — docs

## 12. Add or update a dedicated focus doc

The repo already contains several focus-related docs.

Do one of the following cleanly:

### Preferred
Add a new broad doc:

```text
docs/FOCUS_AND_ANCHORING.md
```

and cross-link it from:
- `docs/SPATIAL_FOCUS.md`
- `docs/2D_Bins_Spatial_Focus.md`
- `docs/FOCUS_AND_GROWTH_CHEATSHEET.md`

### Or
If you prefer not to add a new top-level doc, expand the existing docs consistently.

### Required content

Explain:

- focus point
- anchor
- anchor map
- serial focus
- covert/field focus
- overt/mechanical focus (future concept)
- focus policy
- relation between focus and slot routing

### Important

Be explicit that:
- focus is serial, not simultaneous
- multiple candidates may exist at once, but one active focus is selected at a time
- GrowNet focus is not transformer attention

## 13. Update related docs

Update:
- `docs/SPATIAL_FOCUS.md`
- `docs/FOCUS_AND_GROWTH_CHEATSHEET.md`
- `docs/TRACE_RUNNER.md`
- `docs/INTERACTIVE_RUNNER.md`
- `docs/EXPERIMENT_RUNNER.md`
- `docs/GrowNet_Design_Spec_V5.md` if needed

Do **not** touch `docs/ANCHOR_GUIDELINES.md` unless necessary; that file is about code comment anchors, not GrowNet anchor semantics.

---

# Phase 12 — tests

## 14. Add focused tests

At minimum, add/update tests for:

- scalar anchor-state behavior
- candidate generation for sparse 2D frames
- each focus policy returns deterministic selection
- anchor-map create/update/revisit behavior
- inhibition-of-return behavior
- slot routing relative to active focus
- focus trace output shape
- config parsing for the `focus` block
- interactive session focus summary behavior

### Important

Start by extending current focus-related tests where practical:
- `test_temporal_focus.py`
- `test_spatial_focus.py`

and add new tests only where needed.

Do not write fragile tests that depend on a real terminal or giant images.
Use small deterministic fixtures.

---

# Phase 13 — future work boundary

## 15. Keep overt/mechanical focus as future work

You distinguish between:
- covert / field focus
- overt / mechanical focus

This PR should implement covert/field focus only.

### Do not fake overt focus

No camera/body/head simulation is required in this PR.
That belongs to a later robotics/agent phase.

---

## Acceptance criteria

This PR is complete when:

1. Python has a first-class `FocusEngine` / equivalent runtime layer
2. scalar anchoring is explicit rather than only implicit
3. 2D focus can operate on candidate points when focus mode is enabled
4. existing non-focus `tick_2d()` behavior remains intact unless focus is explicitly enabled
5. focus policies exist:
   - `energy_first`
   - `random_candidate`
   - `sequential_scan`
   - `novelty_first`
   - `familiarity_first`
6. an `AnchorMap` or equivalent remembered-point structure exists
7. focus affects routing before slot selection
8. trace events exist for focus / anchor behavior
9. configs can specify focus policy / settings
10. interactive mode can surface focus behavior
11. docs explain focus and anchoring clearly
12. tests cover the new behavior
13. unsupported or misleading `anchor_mode` surface is cleaned up or made truthful

---

## Explicit non-goals

Do not do these in this PR:

- Java full focus runtime
- Mojo full focus runtime
- C++ full focus runtime
- overt/mechanical focus
- Blender integration
- giant TUI
- image/audio ingestion redesign
- broad unrelated runtime cleanup already completed in earlier PRs

---

## Suggested commit structure

1. add focus runtime types and scalar anchoring formalization
2. add 2D candidate generation and focus policies
3. add anchor map and inhibition-of-return
4. add trace/config/interactive integration
5. update docs and tests

---

## Final response expected from Codex

At the end, provide:

1. summary of what changed
2. files changed
3. which focus concepts are now first-class
4. supported focus policies
5. how anchor maps behave
6. how focus is exposed in trace/config/interactive mode
7. whether current baseline `tick_2d()` behavior was preserved when focus is not enabled
8. tests run
9. what remains for future overt/mechanical focus
