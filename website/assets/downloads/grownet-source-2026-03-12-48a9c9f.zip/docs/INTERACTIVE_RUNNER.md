# INTERACTIVE_RUNNER.md

`./grownet.sh --lang python --interactive` starts a live keyboard-driven GrowNet probing session. `./grownet.sh --lang java --interactive --profile morse_probe` and `./grownet.sh --lang mojo --interactive --profile morse_probe` start the current Java and Mojo Morse temporal sessions.

## Purpose

Interactive mode keeps a persistent GrowNet instance alive so you can press keys, send one input tick at a time, and watch the network adapt or grow from a stable initial scaffold.

Mental model:

- initial scaffold from a built-in profile or config file
- live key input applied one tick at a time
- normal GrowNet slot, neuron, and layer growth still remains active

Reset rebuilds the original scaffold from the same profile/config and returns to tick `0`.

Current implementation note:

- Python and Java Morse sessions keep a persistent live runtime instance
- Mojo currently keeps the accumulated temporal schedule in the host session and replays it through the real Mojo runtime on each step so the temporal semantics stay honest without pretending there is a richer terminal/runtime stack than the current slice actually has

## Scope

Interactive mode is richest in Python, and Java plus Mojo now implement the Morse temporal core slice.

- `--lang python --interactive` is implemented for the full interactive profile set
- `--lang java --interactive --profile morse_probe` supports scripted, live, and replay Morse sessions
- `--lang java --interactive --config experiments/morse_raw_schedule.json` is supported for the same narrow Morse config slice
- `--lang mojo --interactive --profile morse_probe` supports scripted, live, and replay through the host-managed Morse launcher
- `--lang mojo --interactive --config experiments/morse_raw_schedule.json` is supported for the same narrow Morse config slice
- C++ interactive mode is not implemented here

## Flags

- `--interactive`
- `--profile single_scalar|dual_scalar|growth_probe`
- `--profile single_scalar|dual_scalar|growth_probe|morse_probe`
- `--config path/to/experiment.json`
- `--normalize-inputs normalized|raw`
- `--interactive-output compact|verbose|jsonl`
- `--interactive-trace on|off`
- `--interactive-mode scripted|live|replay`
- `--tick-ms 50`
- `--record-schedule path/to/schedule.json`
- `--replay-schedule path/to/schedule.json`
- `--jitter-ms 10`
- `--jitter-pct 0.10`
- `--jitter-seed 0`

Defaults for `./grownet.sh --lang python --interactive`:

- profile: `single_scalar`
- normalize inputs: `normalized`
- output: `compact`
- trace: `off`

## Built-in Profiles

### `single_scalar`

- one scalar input port: `a`
- simple scalar scaffold for immediate probing
- good default for learning slot selection and downstream delivery behavior

### `dual_scalar`

- two scalar input ports: `a` and `b`
- one key press triggers one multi-port tick
- if one port changes, the other port keeps its previous value

### `growth_probe`

- one scalar input port: `a`
- a small scaffold biased toward visible growth
- useful for repeated novelty experiments and reset/replay

### `morse_probe`

- one scalar input port: `signal`
- fixed-cadence raw on/off temporal probing
- intended for pulse/gap experiments without an external decoder
- documented in [MORSE_PROBE.md](C:/Development/Projects/GrowNet/docs/MORSE_PROBE.md)

## Config Support

`--config` loads a JSON file that defines the initial scaffold and interactive defaults.

Interactive mode reuses the same scaffold-oriented config fields documented in `docs/EXPERIMENT_RUNNER.md`, then layers the keyboard-specific interactive defaults on top.

If a config also includes a `morse` block, interactive mode reuses that cadence/pulse configuration for `morse_probe`-style sessions.

Example:

```json
{
  "name": "dual_scalar_probe",
  "interactive": {
    "output": "compact",
    "trace": false,
    "normalize_inputs": "normalized"
  },
  "input_space": {
    "rank": 1,
    "ports": [
      {"name": "a"},
      {"name": "b"}
    ]
  },
  "network": {
    "regions": [
      {
        "name": "main",
        "layers": [
          {
            "excitatory_count": 20,
            "inhibitory_count": 4,
            "modulatory_count": 2
          }
        ]
      }
    ]
  }
}
```

Current behavior:

- the config defines the starting scaffold only
- if no `input_bindings` are provided, all input ports bind to layer `0`
- if no `connections` are provided and a region has multiple layers, consecutive layers auto-connect with probability `1.0`
- keyboard-driven interactive configs are currently meaningful for rank-1 scalar input spaces; shaped file-driven experiments belong to the non-interactive experiment runner path
- if the scaffold/config enables focus, interactive summaries surface the current focus policy, active focus/anchor summary, and remembered anchor count

### Morse Live Input Note

For `morse_probe`, live mode is the closest match to the Python temporal lab:

- Python uses raw key polling directly
- Java uses raw key polling in a real terminal and falls back to line commands when stdin is piped or a raw terminal is unavailable
- Mojo uses raw key polling in the host launcher and replays the accumulated schedule through the real Mojo runtime

In Java and Mojo live mode:

- `space` marks the current cadence window as a one-shot pulse/high tick
- `1` latches sustained high for future ticks
- `0` latches sustained low for future ticks
- `r`, `s`, `t`, `c`, `h`, and `q` remain reset, summary, toggle, clear, help, and quit

If you pipe input instead of using a terminal, Java and Mojo preserve the older line-command fallback for scripted or live sessions.

## Input Mapping

### Normalized mode

- `0 -> 0.0`
- `1 -> 0.1`
- `2 -> 0.2`
- ...
- `9 -> 0.9`

### Raw mode

- `0 -> 0.0`
- `1 -> 1.0`
- `2 -> 2.0`
- ...
- `9 -> 9.0`

## Dual-input Mapping

For `dual_scalar`:

- top-row digits update port `a`
- when the platform exposes distinct keypad tokens, keypad digits update port `b`
- fallback mapping for port `b`: `Q W E R T Y U I O P -> 1 2 3 4 5 6 7 8 9 0`

Example:

- current state: `a=0.2`, `b=0.7`
- press top-row `5`
- next tick uses `a=0.5`, `b=0.7`

- press fallback `E`
- next tick uses `a=0.5`, `b=0.3`

## Control Keys

- `space` = run one tick again with the current input state
- `r` = reset the network to the original scaffold and zeroed inputs
- `s` = print a current summary without advancing the tick
- `t` = toggle compact/verbose summary output
- `c` = reprint the startup panel
- `h` = print help
- `q` = quit

### Morse Probe Control Difference

For `morse_probe`, `space` is the pulse key instead of the repeat key.

- each cadence window that observes the pulse key injects `signal = 1.0`
- `1` latches sustained high so later windows stay at `1.0` until changed
- `0` latches sustained low so later windows stay at `0.0` until changed
- if both a pulse and sustained-low are present in the same window, the one-shot pulse wins for that window only
- `--tick-ms` controls the cadence

### Morse Interactive Modes

- `scripted`: one explicit command advances one tick
- `live`: a cadence loop runs and samples the current signal state each window
- `replay`: a shared temporal schedule is replayed deterministically

See [TEMPORAL_SIGNAL_SCHEDULES.md](C:/Development/Projects/GrowNet/docs/TEMPORAL_SIGNAL_SCHEDULES.md) for the shared schedule format.

### Java Morse Session Commands

Java Morse interactive mode is deliberately simple and testable rather than trying to be a raw-keypress TUI.

- `high` or `1` = inject `signal = 1.0` for one tick
- `low` or `0` = inject `signal = 0.0` for one tick
- `step` = repeat the last signal for one tick
- `hold-on` = latch sustained high for future `step` commands
- `hold-off` = latch sustained low for future `step` commands
- `reset` = rebuild the original Morse scaffold
- `summary` = print the current summary without advancing
- `toggle` = switch compact/verbose output
- `clear` = reprint the startup panel
- `help` = show command help
- `quit` = leave the session

### Mojo Morse Session Commands

Mojo uses the same basic command vocabulary through the host-managed launcher:

- `high` = inject `signal = 1.0` for one tick in scripted mode
- `low` = inject `signal = 0.0` for one tick in scripted mode
- `step` = repeat the last signal in scripted mode
- `hold-on` = latch sustained high for future scripted `step` commands
- `hold-off` = latch sustained low for future scripted `step` commands
- `reset` = rebuild the original Morse scaffold
- `summary` = print the current summary without advancing
- `help` = show command help
- `quit` = leave the session

Mojo live mode is honest but intentionally simple: the host cadence loop samples the current raw signal state and replays the accumulated schedule through the real Mojo Morse runtime.

## Output Modes

### `compact`

One concise line per interactive tick summary.

If focus metadata is available, compact mode appends fields such as `policy=...`, `focus=...`, `anchor=...`, and `anchor_count=...`.

For `morse_probe`, compact mode also appends fields such as `signal=...`, `pulse=...`, `segment_tick=...`, and `tick_ms=...`.

### `verbose`

Multi-line summary with key, port, inputs, metrics, and growth deltas.

When focus metadata is available, verbose mode includes a dedicated focus summary line.

### `jsonl`

One JSON object per summary event, for example:

```json
{"event":"interactive.tick","tick":12,"profile":"dual_scalar","updated_port":"a","input_a":0.4,"input_b":0.7,"fired":true,"delivered_events":1,"total_slots":5,"layer_count":1,"region_count":1}
```

If focus metadata is available, JSONL summaries also include fields such as `focus_policy`, `focus_point`, `focus_value`, `anchor_point`, `anchor_value`, `anchor_count`, and `focus_candidate_count`.

Morse summaries may also include `signal_value`, `pulse_active`, `segment_tick_offset`, and `tick_ms`.

## Trace Interaction

- `--interactive-trace off` keeps interactive summaries only
- `--interactive-trace on` emits full trace events for each tick before the interactive summary
- text summary modes use text trace lines
- `jsonl` summary mode uses JSONL trace lines

## Example Commands

```bash
./grownet.sh --lang python --interactive
./grownet.sh --lang python --interactive --profile dual_scalar
./grownet.sh --lang python --interactive --profile growth_probe --interactive-output verbose
./grownet.sh --lang python --interactive --profile morse_probe
./grownet.sh --lang python --interactive --profile morse_probe --tick-ms 25 --interactive-output verbose
./grownet.sh --lang python --interactive --profile morse_probe --interactive-mode live --record-schedule out/python_capture.json
./grownet.sh --lang python --interactive --profile morse_probe --interactive-mode replay --replay-schedule experiments/morse_temporal_schedule.json --interactive-output jsonl
./grownet.sh --lang java --interactive --profile morse_probe
./grownet.sh --lang java --interactive --profile morse_probe --interactive-mode live --record-schedule out/java_capture.json
./grownet.sh --lang java --interactive --profile morse_probe --interactive-mode replay --replay-schedule experiments/morse_temporal_schedule.json --interactive-output jsonl
./grownet.sh --lang java --interactive --config experiments/morse_raw_schedule.json --interactive-output jsonl
./grownet.sh --lang mojo --interactive --profile morse_probe --interactive-mode live --record-schedule out/mojo_capture.json
./grownet.sh --lang mojo --interactive --profile morse_probe --interactive-mode replay --replay-schedule experiments/morse_temporal_schedule.json --interactive-output jsonl
./grownet.sh --lang python --interactive --config configs/interactive_probe.json --normalize-inputs raw
./grownet.sh --lang python --interactive --profile dual_scalar --interactive-output jsonl --interactive-trace on
```

## Notes

- Interactive mode uses the real Python runtime rather than a toy model.
- Reset rebuilds the original scaffold but keeps the current CLI-selected output and trace settings.
- `morse_probe` is a raw temporal lab. It does not classify dot, dash, or letter symbols outside GrowNet.
- Python remains the strongest true live key-driven path.
- Java interactive support is currently limited to the Morse core slice and uses real terminal key typing when available plus portable command-driven fallback elsewhere.
- Mojo interactive support is also limited to the Morse core slice and uses a host-managed command/cadence layer so shared schedule capture and replay stay portable.
