# PR: Add Morse Probe Mode to GrowNet CLI (Python-First, No External Dot/Dash Classifier)

## Title

interactive: add Morse probe mode with fixed temporal ticks, hold-to-signal input, and GrowNet-internal timing representation

---

## Summary

This PR adds a **Morse probe mode** to GrowNet as a focused temporal experiment.

The goal is **not** to engineer a Morse parser outside the model.

Instead, the goal is to let GrowNet receive:

- a raw on/off temporal signal
- fixed runtime ticks
- live keyboard input or deterministic replay
- normal GrowNet growth / anchoring / focus behavior

and then let GrowNet itself develop internal temporal representations that can eventually distinguish:

- short pulse vs long pulse
- short gap vs long gap
- repeated temporal motifs
- letter-like patterns built from temporal segments

This should be implemented on top of the **current codebase**, which already has:

- interactive mode
- config-driven experiment runner
- benchmark mode
- trace mode
- Focus & Anchoring V1
- scalar and 2D anchoring support
- first-class focus/anchor tracing

This PR should add a **1D temporal lab** for Morse-like probing, not a handcrafted symbolic decoder.

---

## Important architectural rule

Respect GrowNet's language-reference model:

- **Java** = core semantic / architectural reference
- **Python** = Python-language-style reference
- **Mojo** should track Python almost one-to-one
- **C++** follows Java as much as practical

For this PR:

- implement Morse probe mode in **Python first**
- keep Python explicit and readable
- do **not** build a Java-style parser in Python
- structure the implementation so Mojo can later follow the Python version closely

---

## Core principle for this PR

### Time should be represented *inside GrowNet*, not engineered outside it.

That means:

### Allowed outside the model
- a fixed runtime tick loop
- sampling whether a key is currently pressed or not
- deterministic replay of raw on/off sequences

### Not allowed outside the model
- code that says “if held for X ticks, classify as dot”
- code that says “if held for Y ticks, classify as dash”
- any external Morse parser that turns timing into symbols before GrowNet sees it

The desired pipeline is:

```text
raw temporal signal
-> GrowNet neurons / slots / anchors / focus
-> internal temporal microcircuits emerge
-> downstream structure eventually distinguishes short/long pulses and gaps
```

So the runtime provides a clock, but GrowNet provides the meaning of time.

---

## Current codebase baseline

The current repo already includes:

- interactive session support in `src/python/interactive/*`
- config-driven experiments in `src/python/runner/*`
- Focus & Anchoring V1 in `src/python/focus/*`
- trace support in `src/python/debug/*`
- benchmark mode
- config-aware batch / trace / benchmark / interactive modes

This PR should extend that stack rather than creating a separate Morse-specific world.

---

## Required reading before coding

Read these before implementation:

1. `docs/READ_ORDER.md`
2. `docs/LANGUAGE_REFERENCE_POLICY.md`
3. `docs/CODING_STYLE_MUST_READ.md`
4. `docs/GOLDEN_RULE.md`
5. `docs/GROWTH.md`
6. `docs/CREATION_AND_GROWTH_POINTS.md`
7. `docs/contracts/grownet.contract.v5.json`
8. `docs/GrowNet_Design_Spec_V5.md`
9. `docs/FOCUS_AND_ANCHORING.md`
10. `docs/SPATIAL_FOCUS.md`
11. `docs/TRACE_RUNNER.md`
12. `docs/INTERACTIVE_RUNNER.md`
13. `docs/EXPERIMENT_RUNNER.md`
14. `docs/BENCHMARK_RUNNER.md`

Also review the current code in:
- `src/python/interactive/interactive_main.py`
- `src/python/interactive/interactive_session.py`
- `src/python/interactive/interactive_keyboard.py`
- `src/python/interactive/interactive_profiles.py`
- `src/python/region.py`
- `src/python/runner/experiment_config.py`
- `src/python/runner/run_mode_dispatch.py`
- `src/python/focus/*`

---

## Coding style requirements

These are mandatory:

- Follow `docs/CODING_STYLE_MUST_READ.md`
- No single- or double-character identifiers anywhere, including loops
- Keep Python explicit and readable
- Avoid clever one-liners
- Preserve determinism
- Preserve two-phase tick discipline
- Do not introduce a symbolic Morse parser outside GrowNet
- Do not change current non-Morse runtime semantics unless clearly necessary
- Prefer obvious helper modules over giant files

---

## Scope

### Implement in this PR

1. Morse probe profile for interactive mode
2. fixed temporal tick support for hold-to-signal probing
3. raw signal on/off injection into GrowNet
4. optional deterministic replay of raw on/off temporal schedules
5. config support for Morse experiments
6. trace hooks for temporal probing
7. docs and tests
8. optional minimal benchmark support for Morse schedules if it stays small and clean

### Do not implement in this PR

- external dot/dash classifier
- external letter decoder
- full Morse transcription engine
- Java Morse runtime
- Mojo Morse runtime
- C++ Morse runtime
- overt/mechanical focus
- Blender integration
- audio-file Morse decoding
- speculative world-model redesign

---

# Phase 1 — add a Morse profile to interactive mode

## 1. Add a built-in interactive profile: `morse_probe`

Add a new interactive profile alongside:
- `single_scalar`
- `dual_scalar`
- `growth_probe`

### New profile
`morse_probe`

### Purpose
A simple 1D temporal scaffold that makes pulse and gap timing easy to probe.

### Requirements

- one primary scalar input port, for example `signal`
- optional secondary scalar input port only if needed for future tempo or control experiments, but keep V1 minimal
- small initial scaffold, for example:
  - one or two layers
  - enough excitatory/inhibitory/modulatory neurons to let temporal structure emerge
- enable focus/anchoring defaults appropriate for 1D temporal input

### Important

This profile defines the **initial scaffold only**.
GrowNet still remains free to:
- add slots
- add neurons
- add layers
- add regions

---

# Phase 2 — fixed temporal tick support

## 2. Add explicit runtime tick cadence for Morse mode

Interactive Morse probing needs a real temporal cadence.

Add support for something like:

```text
--tick-ms 50
```

### Meaning

One runtime step occurs every `tick-ms` milliseconds.

### Important

This is not an external time classifier.
It is simply the sampling cadence that lets GrowNet experience duration over ticks.

### Default

Choose a reasonable default, for example:
- `50 ms`

Document it clearly.

---

# Phase 3 — hold-to-signal mode

## 3. Add hold-to-signal behavior in interactive mode

In Morse probe mode, interactive mode should support:

- key held down -> signal stays high on each tick
- key released -> signal stays low on each tick

### Preferred key
Use `spacebar` as the default pulse key.

### Behavior

- while the pulse key is held, each clock tick injects `signal = 1.0`
- while it is not held, each clock tick injects `signal = 0.0`

### Important

The runtime should not convert this into:
- dot
- dash
- short gap
- long gap

Those meanings must emerge from GrowNet state.

---

# Phase 4 — replay mode for deterministic experiments

## 4. Add deterministic replay of raw temporal schedules

Interactive live hold mode is great, but you also need repeatable experiments.

Support a config/input format that replays raw temporal schedules such as:

```json
{
  "name": "morse_e_probe",
  "runtime": {
    "ticks": 20,
    "interactive": false
  },
  "input_space": {
    "rank": 1,
    "shape": [1],
    "ports": [{"name": "signal"}]
  },
  "network": {
    "regions": [
      {
        "name": "main",
        "layers": [
          {"excitatory_count": 8, "inhibitory_count": 2, "modulatory_count": 1}
        ]
      }
    ]
  },
  "input": {
    "type": "sequence",
    "values": [1,1,0,0,0,0,0,0]
  },
  "morse": {
    "tick_ms": 50,
    "mode": "raw_schedule"
  }
}
```

### Important

This is still raw on/off temporal input.
It is **not** symbol parsing.

---

# Phase 5 — optional idealized helper mode, but still raw

## 5. Optional helper for deterministic pulse templates

If you add convenience helpers, they must still expand only into raw schedules.

### Acceptable
A helper like:

```json
{
  "morse": {
    "template": "dot"
  }
}
```

only if it expands internally to a raw sequence like:
`[1, 0]` or `[1,1,0,0]` depending on tick cadence and configured unit length.

### Not acceptable
Any helper that then classifies output as:
- dot
- dash
- A
- B
- SOS

Helpers may produce **raw on/off schedules only**.

If this risks confusion, skip template helpers in V1 and stay with explicit raw schedules.

---

# Phase 6 — temporal anchoring inside GrowNet

## 6. Formalize temporal anchoring for Morse probing

This PR should lean into the idea that:

- onset of a pulse can serve as a temporal anchor
- evolving internal state over subsequent ticks becomes GrowNet's representation of elapsed time

### Requirements

Where practical, expose or formalize:

- temporal focus/anchor metadata in the 1D path
- segment start / anchor start semantics
- distance-from-anchor in temporal terms
- compatibility with current scalar anchoring machinery

### Important

Do not add a special “time neuron type” in this PR unless absolutely necessary.

Preferred approach:
- let time be represented by existing GrowNet neuron dynamics, recurrence, modulation, anchoring, and evolving slot/circuit state

If a tiny helper abstraction is needed, keep it minimal and generic.

---

# Phase 7 — optional edge helpers, but not symbolic decoding

## 7. Consider adding transition-aware raw channels only if they remain generic

If needed, it is acceptable to add optional **generic temporal helper channels** such as:

- onset edge
- offset edge

But only if they are:
- generic
- optional
- still raw and low-level
- not Morse-specific symbolic labels

### Important

Do not add features like:
- `is_dot`
- `is_dash`
- `is_letter_gap`

Those belong to the model's learned interpretation, not runner plumbing.

If possible, keep V1 to a single raw signal channel only.

---

# Phase 8 — trace support for Morse probing

## 8. Add trace visibility for temporal probing

Extend trace support so Morse probe runs are easy to inspect.

Add fields or events that help explain:
- current tick
- current signal value
- whether the signal is in a pulse or gap
- current temporal anchor if available
- focus/anchor summary if present
- slot reuse / fallback / growth during repeated timing patterns

### Important

This should stay generic and compatible with the current trace vocabulary.
If a Morse-specific trace helper is added, keep it very small and honest.

---

# Phase 9 — interactive output improvements

## 9. Add Morse-friendly compact output

Interactive output in Morse mode should help the user feel what the model is doing.

### Example compact output

```text
tick=12 signal=1.0 pulse=true anchor=4 slot=2 fired=true delivered=1 total_slots=5
```

### Example with focus metadata

```text
tick=12 signal=1.0 pulse=true focus_policy=temporal_anchor anchor_value=4.0 slot=2 fired=true delivered=1
```

### Important

Do not show decoded letters unless a separate, explicitly external decoder exists later.
This PR is about probing the model, not pretending it already reads Morse.

---

# Phase 10 — config support

## 10. Add a small `morse` block to experiment/interactive config

Support a config block like:

```json
{
  "morse": {
    "enabled": true,
    "tick_ms": 50,
    "pulse_key": "space",
    "hold_mode": true
  }
}
```

### Purpose

This is not a semantic decoder.
It only configures:
- temporal cadence
- key mapping
- replay/hold behavior

### Important

The rest of the meaning still lives in GrowNet.

---

# Phase 11 — tests

## 11. Add focused tests

At minimum, test:

- `morse_probe` profile loads correctly
- `--tick-ms` parsing works
- hold-to-signal logic produces repeated high ticks while pressed
- release produces low ticks
- deterministic raw schedule replay works
- current non-Morse interactive behavior remains intact
- config parsing for the `morse` block works
- trace/summary output shape for Morse mode is stable

### Important

Do not write tests that claim Morse is “recognized” yet.
Only test runner behavior, schedule generation, and model plumbing.

---

# Phase 12 — docs

## 12. Add a dedicated Morse probe doc

Create:

```text
docs/MORSE_PROBE.md
```

Include:

- why Morse is a good GrowNet experiment
- fixed ticks as substrate, not interpretation
- hold-to-signal mode
- raw schedule replay
- `morse_probe` profile
- examples of interactive use
- examples of config-based deterministic runs
- explicit statement that:
  - the runner does not classify dot/dash
  - timing meaning is intended to emerge inside GrowNet

## 13. Update related docs

Update:
- `docs/INTERACTIVE_RUNNER.md`
- `docs/EXPERIMENT_RUNNER.md`
- `docs/TRACE_RUNNER.md`
- `docs/BENCHMARK_RUNNER.md` only if benchmark integration is included
- `docs/FOCUS_AND_ANCHORING.md` if the temporal anchor explanation needs a short Morse section

---

# Phase 13 — optional benchmark integration

## 14. Optional, only if it stays small and clean

If easy, allow benchmark mode to run Morse raw schedules from config.

Example:

```bash
./grownet.sh --lang python --benchmark --config experiments/morse_dot.json
```

### Important

Benchmark the runner/runtime path only.
Do not benchmark symbolic decoding because this PR should not add any.

If this adds too much scope, skip it.

---

## Acceptance criteria

This PR is complete when:

1. `./grownet.sh --lang python --interactive --profile morse_probe` works
2. Morse probe mode supports fixed runtime ticks
3. live hold-to-signal behavior works
4. deterministic raw schedule replay works from config
5. no external dot/dash or letter decoder is introduced
6. current interactive/config/trace behavior remains intact for non-Morse modes
7. docs explain Morse probe mode clearly
8. tests cover the new plumbing
9. time meaning remains inside GrowNet rather than being classified outside it

---

## Explicit non-goals

Do not do these in this PR:

- external Morse decoder
- symbolic dot/dash classifier
- letter/word recognition pipeline
- Java Morse runtime
- Mojo Morse runtime
- C++ Morse runtime
- audio Morse decoding
- overt/mechanical focus
- robotics coupling

---

## Suggested commit structure

1. add `morse_probe` profile and tick cadence support
2. add hold-to-signal interactive logic
3. add config-driven raw schedule replay
4. add docs and tests
5. optional benchmark integration if small

---

## Final response expected from Codex

At the end, provide:

1. summary of what changed
2. files changed
3. example interactive Morse commands
4. example config-driven Morse runs
5. how hold-to-signal works
6. tests run
7. confirmation that no external dot/dash classifier was added
8. follow-up ideas for future learned Morse recognition experiments
