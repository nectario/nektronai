# MORSE_PROBE.md

`./grownet.sh --lang python --interactive --profile morse_probe` starts a fixed-cadence temporal probe for raw Morse-like on/off input.

## Purpose

Morse probe mode is a 1D temporal lab for GrowNet.

The runner provides:

- a fixed tick cadence
- a raw on/off input signal
- live timing capture
- deterministic replay from config or shared schedule files
- schedule recording
- deterministic jittered replay

GrowNet provides:

- slot reuse and fallback
- neuron firing and delivery
- scalar anchoring and focus summaries
- normal growth after the session starts

This mode does **not** classify:

- dot
- dash
- letter
- word

The point is to let timing meaning emerge inside GrowNet rather than decoding it outside the model.

## Interactive Morse Profile

Built-in profile:

- `morse_probe`

Default behavior:

- one scalar input port: `signal`
- fixed cadence: `50 ms`
- pulse key: `space`
- sustained-high latch key: `1`
- sustained-low latch key: `0`
- raw signal values:
  - pulse window -> `1.0`
  - no pulse with sustained-high active -> `1.0`
  - no pulse with sustained-high inactive -> `0.0`

The profile defines only the initial scaffold. GrowNet may still add slots, neurons, layers, or regions afterward.

## Live Temporal Control Model

Interactive Morse mode uses a cadence loop.

- each cadence step runs one GrowNet tick
- `space` creates a one-shot pulse for the current cadence window only
- `1` latches sustained high for future windows until changed
- `0` latches sustained low for future windows until changed

Effective signal rule for each cadence window:

- if a one-shot pulse was seen in the current window, inject `signal = 1.0`
- otherwise if sustained high is active, inject `signal = 1.0`
- otherwise inject `signal = 0.0`

Reset rule:

- `reset` clears the recorded schedule
- `reset` clears any pending pulse in the current cadence window
- `reset` clears sustained high/low state back to low
- the first post-reset tick is low unless you explicitly create new high input after the reset

Terminal note:

- standard terminals usually do not expose true key-release events
- this implementation therefore uses explicit one-shot pulse plus explicit sustained state instead of pretending to track perfect physical key-down / key-up state in every terminal
- Python remains the strongest true live key-driven path
- Java uses real terminal key typing when available and falls back to portable scripted/line control when needed
- Mojo live mode is host-managed by the launcher, which captures the temporal control state and replays it through the real Mojo runtime

That keeps the runner honest about what the terminals actually provide while still giving a useful live temporal probe.

## CLI Flags

- `--interactive`
- `--profile morse_probe`
- `--interactive-mode scripted|live|replay`
- `--tick-ms 50`
- `--interactive-output compact|verbose|jsonl`
- `--interactive-trace on|off`
- `--config path/to/experiment.json`
- `--record-schedule path/to/schedule.json`
- `--replay-schedule path/to/schedule.json`
- `--jitter-ms 10`
- `--jitter-pct 0.10`
- `--jitter-seed 0`

## Example Interactive Commands

```bash
./grownet.sh --lang python --interactive --profile morse_probe
./grownet.sh --lang python --interactive --profile morse_probe --interactive-mode live --record-schedule out/python_capture.json
./grownet.sh --lang python --interactive --profile morse_probe --interactive-mode replay --replay-schedule experiments/morse_temporal_schedule.json
./grownet.sh --lang python --interactive --profile morse_probe --tick-ms 25
./grownet.sh --lang python --interactive --profile morse_probe --interactive-output verbose --interactive-trace on
./grownet.sh --lang python --interactive --config experiments/morse_raw_schedule.json
```

## Java and Mojo Scope

This repository now includes a complete Java Morse core slice and a complete temporal core slice for Mojo through the host-managed launcher.

- Java supported:
  - `./grownet.sh --lang java --scenario morse_probe`
  - `./grownet.sh --lang java --config experiments/morse_raw_schedule.json`
  - `./grownet.sh --lang java --interactive --profile morse_probe`
  - `./grownet.sh --lang java --interactive --profile morse_probe --interactive-mode live`
  - `./grownet.sh --lang java --interactive --profile morse_probe --interactive-mode replay --replay-schedule experiments/morse_temporal_schedule.json`
  - `./grownet.sh --lang java --interactive --config experiments/morse_raw_schedule.json`
  - `./grownet.sh --lang java --trace --trace-format jsonl --config experiments/morse_raw_schedule.json`
  - `./grownet.sh --lang java --benchmark --config experiments/morse_raw_schedule.json`
- Java not supported:
  - general non-Morse config-driven execution
  - full Java experiment-runner parity

Java scope notes:

- Java supports the built-in `morse_probe` scenario.
- Java supports the checked-in `experiments/morse_raw_schedule.json` config and compatible inline rank-1 Morse sequence configs.
- Java interactive probing now supports both:
  - real terminal live keys when available:
    - `space` = one-shot pulse for the current cadence window
    - `1` = latch sustained high
    - `0` = latch sustained low
    - `r`, `s`, `t`, `c`, `h`, `q` = reset, summary, toggle, clear, help, quit
  - portable scripted/line control when stdin is piped or a raw terminal is unavailable:
    - `high|1`
    - `low|0`
    - `step`
    - `hold-on`
    - `hold-off`
    - `reset`
    - `summary`
    - `toggle`
    - `clear`
    - `help`
    - `quit`
- Java honors Morse cadence metadata such as `tick_ms` for trace/benchmark visibility, but it does not classify dots, dashes, letters, or words.
- Java does not yet implement the broader Python experiment-runner config surface for non-Morse experiments.

### Mojo Scope

- supported:
  - `./grownet.sh --lang mojo --scenario morse_probe`
  - `./grownet.sh --lang mojo --config experiments/morse_raw_schedule.json`
  - `./grownet.sh --lang mojo --trace --trace-format jsonl --scenario morse_probe`
  - `./grownet.sh --lang mojo --interactive --profile morse_probe --interactive-mode scripted`
  - `./grownet.sh --lang mojo --interactive --profile morse_probe --interactive-mode live`
  - `./grownet.sh --lang mojo --interactive --profile morse_probe --interactive-mode replay --replay-schedule experiments/morse_temporal_schedule.json`
  - `./grownet.sh --lang mojo --benchmark --config experiments/morse_raw_schedule.json`
- not supported:
  - general non-Morse config-driven execution

Mojo support remains raw-schedule only, and it reuses the existing Mojo `Region.tick(...)` path rather than adding any external dot/dash classifier.

Mojo live input note:

- live mode uses raw key polling in the host launcher
- `space` marks the current cadence window as a one-shot pulse/high
- `1` latches sustained high for future windows
- `0` latches sustained low for future windows
- reset clears both the recorded schedule and the current live pulse/sustained state
- when stdin is piped instead of attached to a terminal, Mojo falls back to the portable line-command live path

Launcher note:

- if `mojo` is on the host PATH, the runner uses it directly
- otherwise the launcher will also detect a repo-local pixi install at `src/mojo/.pixi/envs/default/bin/mojo` and run it through WSL automatically

## Config-Driven Raw Schedule Replay

Morse experiments can also replay a deterministic raw schedule from config.

Example:

```json
{
  "name": "morse_raw_schedule",
  "runtime": {
    "ticks": 8
  },
  "morse": {
    "enabled": true,
    "tick_ms": 50,
    "pulse_key": "space",
    "hold_mode": true,
    "mode": "raw_schedule"
  },
  "input_space": {
    "rank": 1,
    "shape": [1],
    "ports": [{"name": "signal"}]
  },
  "network": {
    "regions": [
      {
        "name": "main",
        "layers": [
          {"excitatory_count": 4, "inhibitory_count": 1, "modulatory_count": 1}
        ]
      }
    ]
  },
  "input": {
    "type": "sequence",
    "values": [1, 1, 0, 0, 1, 0, 0, 0]
  }
}
```

This is still raw on/off temporal input. It is not symbolic Morse parsing.

Shared temporal schedule replay is also supported directly:

```bash
./grownet.sh --lang python --interactive --profile morse_probe --interactive-mode replay --replay-schedule experiments/morse_temporal_schedule.json
./grownet.sh --lang java --interactive --profile morse_probe --interactive-mode replay --replay-schedule experiments/morse_temporal_schedule.json
./grownet.sh --lang mojo --interactive --profile morse_probe --interactive-mode replay --replay-schedule experiments/morse_temporal_schedule.json
```

See [TEMPORAL_SIGNAL_SCHEDULES.md](C:/Development/Projects/GrowNet/docs/TEMPORAL_SIGNAL_SCHEDULES.md) for the shared format and record/replay flow.

Mojo can replay the same raw schedule:

```bash
./grownet.sh --lang mojo --config experiments/morse_raw_schedule.json
./grownet.sh --lang mojo --benchmark --config experiments/morse_raw_schedule.json --benchmark-warmup 25 --benchmark-iterations 250 --benchmark-repeat 3
```

## Trace Visibility

When tracing is enabled, Morse probing adds a small raw-signal trace event:

- `morse.signal`

Mojo trace mode for the current slice also emits per-tick `tick.end` summaries so the trace stream includes both raw input state and resulting per-tick totals.

Typical fields:

- `tick`
- `input_port`
- `signal_value`
- `pulse_active`
- `tick_ms`

This event is only there to expose the raw temporal probe state. It does not claim any learned interpretation.

## Temporal Anchoring

Morse probing leans on GrowNet's existing scalar anchoring and evolving recurrent state.

- pulse onset provides a natural raw reference point
- later ticks are experienced by the same runtime as later moments relative to that raw pulse/gap history
- interactive summaries can surface the current scalar anchor/focus metadata when the runtime produces it

This is still covert temporal probing, not a symbolic decoder and not overt/mechanical focus.

## Scope Notes

- Python remains the richer Morse experimentation surface
- Java now supports the complete Morse core slice for run, trace, benchmark, scripted probing, live cadence capture, and replay
- no external dot/dash classifier
- no external letter decoder
- no audio Morse decoder in this PR
- Mojo supports the temporal core slice through a host-managed scripted/live/replay launcher plus the current Morse trace path
