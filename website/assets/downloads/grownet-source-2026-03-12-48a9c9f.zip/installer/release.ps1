[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)][string]$Version,
  [ValidateSet('Debug','Release')][string]$Configuration = 'Release',
  [string]$Runtime = 'win-x64',
  [string]$Framework = 'net10.0-windows',
  [string]$DeployRoot = '',
  [string]$DownloadBaseUrl = '',
  [string]$Bucket = '',
  [string]$Region = '',
  [string]$Channel = 'latest',
  [string]$SignPfx = '',
  [string]$SignPfxPassword = '',
  [string]$TimestampUrl = 'http://timestamp.digicert.com'
)

$ErrorActionPreference = 'Stop'

function Get-FourPartVersion([string]$rawVersionText) {
  $parts = $rawVersionText.Split('.')
  while ($parts.Length -lt 4) {
    $parts += '0'
  }
  return ($parts[0..3] -join '.')
}

function Update-VersionProps([string]$propsFilePath, [string]$versionText) {
  [xml]$propsXml = Get-Content -Path $propsFilePath
  $fourPartVersion = Get-FourPartVersion $versionText
  $propsXml.Project.PropertyGroup.Version = $versionText
  $propsXml.Project.PropertyGroup.AssemblyVersion = $fourPartVersion
  $propsXml.Project.PropertyGroup.FileVersion = $fourPartVersion
  $propsXml.Project.PropertyGroup.InformationalVersion = $versionText
  $utf8NoBomEncoding = New-Object System.Text.UTF8Encoding($false)
  $stringWriter = New-Object System.IO.StringWriter
  $xmlWriterSettings = New-Object System.Xml.XmlWriterSettings
  $xmlWriterSettings.Indent = $true
  $xmlWriterSettings.OmitXmlDeclaration = $true
  $xmlWriter = [System.Xml.XmlWriter]::Create($stringWriter, $xmlWriterSettings)
  $propsXml.Save($xmlWriter)
  $xmlWriter.Dispose()
  [System.IO.File]::WriteAllText($propsFilePath, $stringWriter.ToString(), $utf8NoBomEncoding)
}

function Invoke-AwsCommand {
  param(
    [Parameter(Mandatory = $true)][string[]]$Arguments
  )

  $awsCommand = Get-Command aws -ErrorAction SilentlyContinue
  if (-not $awsCommand) {
    throw "AWS CLI is required for S3 deployment. Install AWS CLI or omit the bucket settings."
  }

  & $awsCommand.Source @Arguments
  if ($LASTEXITCODE -ne 0) {
    throw "AWS CLI command failed: aws $($Arguments -join ' ')"
  }
}

function Get-S3BaseUrl([string]$bucketName, [string]$regionName) {
  if ([string]::IsNullOrWhiteSpace($bucketName) -or [string]::IsNullOrWhiteSpace($regionName)) {
    return ''
  }
  return "https://$bucketName.s3.$regionName.amazonaws.com"
}

$installerRootPath = Split-Path -Parent $MyInvocation.MyCommand.Definition
$repoRootPath = Resolve-Path (Join-Path $installerRootPath '..')
$versionPropsPath = Join-Path $repoRootPath 'tools\GrowNetLab\Directory.Build.props'
$artifactDirectoryPath = Join-Path $installerRootPath 'artifacts'
$deployDirectoryPath = if ([string]::IsNullOrWhiteSpace($DeployRoot)) { $env:GROWNET_LAB_DEPLOY_ROOT } else { $DeployRoot }
$bucketName = if ([string]::IsNullOrWhiteSpace($Bucket)) { $env:GROWNET_LAB_AWS_BUCKET } else { $Bucket }
$regionName = if ([string]::IsNullOrWhiteSpace($Region)) {
  if ([string]::IsNullOrWhiteSpace($env:GROWNET_LAB_AWS_REGION)) { 'us-east-2' } else { $env:GROWNET_LAB_AWS_REGION }
} else {
  $Region
}
$channelName = if ([string]::IsNullOrWhiteSpace($Channel)) { 'latest' } else { $Channel }
$defaultDownloadBaseUrlText = Get-S3BaseUrl $bucketName $regionName
$downloadBaseUrlText = if ([string]::IsNullOrWhiteSpace($DownloadBaseUrl)) {
  if ([string]::IsNullOrWhiteSpace($env:GROWNET_LAB_DOWNLOAD_BASE_URL)) { $defaultDownloadBaseUrlText } else { $env:GROWNET_LAB_DOWNLOAD_BASE_URL }
} else {
  $DownloadBaseUrl
}

Update-VersionProps $versionPropsPath $Version

& (Join-Path $installerRootPath 'build.ps1') `
  -Configuration $Configuration `
  -Runtime $Runtime `
  -Framework $Framework `
  -SignPfx $SignPfx `
  -SignPfxPassword $SignPfxPassword `
  -TimestampUrl $TimestampUrl

$msiPath = Join-Path $artifactDirectoryPath 'GrowNetLab.msi'
$bundlePath = Join-Path $artifactDirectoryPath 'GrowNetLabSetup.exe'
$manifestPath = Join-Path $artifactDirectoryPath 'GrowNetLab-latest.json'
$releasePrefix = "releases/$Version"
$channelPrefix = $channelName

$manifest = [ordered]@{
  product = 'GrowNet Lab'
  channel = $channelName
  version = $Version
  artifact_version = $Version
  generated_at_utc = [DateTime]::UtcNow.ToString('o')
  files = [ordered]@{
    msi = [ordered]@{
      name = 'GrowNetLab.msi'
      url = if ($downloadBaseUrlText) { "$downloadBaseUrlText/$channelPrefix/GrowNetLab.msi" } else { '' }
      release_url = if ($downloadBaseUrlText) { "$downloadBaseUrlText/$releasePrefix/GrowNetLab.msi" } else { '' }
    }
    bundle = [ordered]@{
      name = 'GrowNetLabSetup.exe'
      url = if ($downloadBaseUrlText) { "$downloadBaseUrlText/$channelPrefix/GrowNetLabSetup.exe" } else { '' }
      release_url = if ($downloadBaseUrlText) { "$downloadBaseUrlText/$releasePrefix/GrowNetLabSetup.exe" } else { '' }
    }
  }
}

$manifest | ConvertTo-Json -Depth 8 | Set-Content -Path $manifestPath -Encoding UTF8

if (-not [string]::IsNullOrWhiteSpace($bucketName)) {
  $releaseMsiKey = "$releasePrefix/GrowNetLab.msi"
  $releaseBundleKey = "$releasePrefix/GrowNetLabSetup.exe"
  $channelMsiKey = "$channelPrefix/GrowNetLab.msi"
  $channelBundleKey = "$channelPrefix/GrowNetLabSetup.exe"
  $channelManifestKey = "$channelPrefix/latest.json"

  Invoke-AwsCommand -Arguments @('s3', 'cp', $msiPath, "s3://$bucketName/$releaseMsiKey", '--region', $regionName, '--cache-control', 'public, max-age=31536000, immutable')
  Invoke-AwsCommand -Arguments @('s3', 'cp', $bundlePath, "s3://$bucketName/$releaseBundleKey", '--region', $regionName, '--cache-control', 'public, max-age=31536000, immutable')

  Invoke-AwsCommand -Arguments @('s3', 'cp', "s3://$bucketName/$releaseMsiKey", "s3://$bucketName/$channelMsiKey", '--region', $regionName, '--metadata-directive', 'REPLACE', '--cache-control', 'public, max-age=300')
  Invoke-AwsCommand -Arguments @('s3', 'cp', "s3://$bucketName/$releaseBundleKey", "s3://$bucketName/$channelBundleKey", '--region', $regionName, '--metadata-directive', 'REPLACE', '--cache-control', 'public, max-age=300')
  Invoke-AwsCommand -Arguments @('s3', 'cp', $manifestPath, "s3://$bucketName/$channelManifestKey", '--region', $regionName, '--content-type', 'application/json', '--cache-control', 'no-cache')
}

if (-not [string]::IsNullOrWhiteSpace($deployDirectoryPath)) {
  New-Item -ItemType Directory -Force -Path $deployDirectoryPath | Out-Null
  Copy-Item -Path $msiPath -Destination (Join-Path $deployDirectoryPath 'GrowNetLab.msi') -Force
  Copy-Item -Path $bundlePath -Destination (Join-Path $deployDirectoryPath 'GrowNetLabSetup.exe') -Force
  Copy-Item -Path $manifestPath -Destination (Join-Path $deployDirectoryPath 'GrowNetLab-latest.json') -Force
}

Write-Host "Release prepared for GrowNet Lab $Version" -ForegroundColor Green
Write-Host "Artifacts: $artifactDirectoryPath"
if (-not [string]::IsNullOrWhiteSpace($deployDirectoryPath)) {
  Write-Host "Deploy target: $deployDirectoryPath"
}
if (-not [string]::IsNullOrWhiteSpace($bucketName)) {
  Write-Host "S3 channel: s3://$bucketName/$channelPrefix" -ForegroundColor Green
}
