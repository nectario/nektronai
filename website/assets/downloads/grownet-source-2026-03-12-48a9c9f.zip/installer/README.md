# GrowNet Lab Installer

This folder packages the **WPF GrowNet Lab** as a Windows installer.

The installer intentionally ships the **lab app only**. It does **not** install the full GrowNet source repository. On first launch, the app asks for a local GrowNet source root and uses that for the Python, Java, and Mojo runtime adapters.

## Requirements

- .NET SDK 10 for local build/publish
- WiX Toolset v6 on `PATH`
- Windows PowerShell or PowerShell 7

## Build

```powershell
cd installer
./build.ps1
```

That script will:

- publish `tools/GrowNetLab/app/GrowNetLab.App`
- generate installer branding assets
- build `GrowNetLab.msi`
- build `GrowNetLabSetup.exe`

Artifacts land under:

- `installer/artifacts/GrowNetLab.msi`
- `installer/artifacts/GrowNetLabSetup.exe`

## Release flow

```powershell
cd installer
./release.ps1 -Version 0.1.1
```

That script will:

- update `tools/GrowNetLab/Directory.Build.props`
- rebuild the installer artifacts
- emit `installer/artifacts/GrowNetLab-latest.json`

If you provide a deploy target, the release script will also copy the artifacts there:

```powershell
./release.ps1 -Version 0.1.1 -DeployRoot C:\inetpub\wwwroot\downloads\grownet
```

You can also set environment variables instead:

- `GROWNET_LAB_DEPLOY_ROOT`
- `GROWNET_LAB_DOWNLOAD_BASE_URL`

## S3 / website release channel

The release script can also publish versioned artifacts and refresh a channel manifest in S3, similar to the InterviewHelperAI release flow.

Example:

```powershell
./release.ps1 -Version 0.1.1 -Bucket my-grownet-downloads -Region us-east-2 -Channel latest
```

That will:

- upload versioned artifacts to `releases/<version>/`
- refresh channel pointers under `<channel>/`
- upload `<channel>/latest.json`

Supported environment variables:

- `GROWNET_LAB_AWS_BUCKET`
- `GROWNET_LAB_AWS_REGION`
- `GROWNET_LAB_DOWNLOAD_BASE_URL`

When `GROWNET_LAB_DOWNLOAD_BASE_URL` is not provided, the script derives it from the bucket and region as:

- `https://<bucket>.s3.<region>.amazonaws.com`

The generated manifest advertises channel URLs like:

- `https://<bucket>.s3.<region>.amazonaws.com/latest/GrowNetLabSetup.exe`
- `https://<bucket>.s3.<region>.amazonaws.com/latest/latest.json`

## Installer behavior

- per-user install under `%LocalAppData%\NektronAI\GrowNetLab`
- self-contained publish, so the installer does not depend on a separate .NET Desktop runtime install
- first-run source-root onboarding inside the app

## Scope notes

This installer is for the **GrowNet Lab desktop shell**. Runtime code remains in the user’s GrowNet source checkout, which avoids shipping a stale repo snapshot inside the installer.
