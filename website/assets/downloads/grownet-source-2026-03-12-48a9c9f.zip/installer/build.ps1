[CmdletBinding()]
param(
  [ValidateSet('Debug','Release')][string]$Configuration = 'Release',
  [string]$Runtime = 'win-x64',
  [string]$Framework = 'net10.0-windows',
  [switch]$SelfContained = $true,
  [string]$SignPfx = '',
  [string]$SignPfxPassword = '',
  [string]$TimestampUrl = 'http://timestamp.digicert.com'
)

$ErrorActionPreference = 'Stop'

function Write-Info([string]$messageText) {
  Write-Host $messageText -ForegroundColor Cyan
}

function Get-FourPartVersion([string]$rawVersionText) {
  $parts = $rawVersionText.Split('.')
  while ($parts.Length -lt 4) {
    $parts += '0'
  }
  return ($parts[0..3] -join '.')
}

function Read-LabVersion([string]$propsFilePath) {
  [xml]$propsXml = Get-Content -Path $propsFilePath
  $versionText = $propsXml.Project.PropertyGroup.Version
  if ([string]::IsNullOrWhiteSpace($versionText)) {
    throw "Version is missing in $propsFilePath"
  }
  return $versionText
}

function Ensure-Directory([string]$directoryPath) {
  New-Item -ItemType Directory -Force -Path $directoryPath | Out-Null
}

function Write-InstallerLicense([string]$licenseFilePath) {
  $licenseText = @'
{\rtf1\ansi\deff0
{\fonttbl{\f0 Segoe UI;}}
\fs22 GrowNet Lab Installer License\par
\par
This installer packages the GrowNet Lab desktop app only.\par
The GrowNet source repository is not installed by this package.\par
\par
On first launch, configure the app with a local GrowNet source root so the Python, Java, and Mojo adapters can run the existing GrowNet runtimes.\par
\par
Use of GrowNet Lab remains subject to your project and repository licensing terms.\par
}
'@
  Set-Content -Path $licenseFilePath -Value $licenseText -Encoding ASCII
}

function Write-BrandBitmap(
  [string]$outputFilePath,
  [int]$width,
  [int]$height,
  [string]$headlineText,
  [string]$subheadText
) {
  Add-Type -AssemblyName System.Drawing

  $bitmap = [System.Drawing.Bitmap]::new($width, $height, [System.Drawing.Imaging.PixelFormat]::Format24bppRgb)
  $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
  try {
    $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
    $graphics.Clear([System.Drawing.Color]::FromArgb(30, 31, 34))

    $accentBrush = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(94, 162, 255))
    $primaryBrush = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(242, 244, 248))
    $secondaryBrush = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(176, 184, 196))
    $headlineFont = [System.Drawing.Font]::new('Segoe UI Semibold', [Math]::Max(16, [int]($height / 8)))
    $subheadFont = [System.Drawing.Font]::new('Segoe UI', [Math]::Max(9, [int]($height / 18)))

    $graphics.FillRectangle($accentBrush, 0, 0, [Math]::Max(10, [int]($width * 0.02)), $height)
    $graphics.DrawString($headlineText, $headlineFont, $primaryBrush, 26, [Math]::Max(6, [int]($height * 0.18)))
    $graphics.DrawString($subheadText, $subheadFont, $secondaryBrush, 28, [Math]::Max(34, [int]($height * 0.52)))

    $bitmap.Save($outputFilePath, [System.Drawing.Imaging.ImageFormat]::Bmp)
  }
  finally {
    $graphics.Dispose()
    $bitmap.Dispose()
  }
}

function Resolve-SigntoolPath {
  try {
    return (Get-Command signtool -ErrorAction Stop).Source
  }
  catch {
  }

  $windowsSdkRoots = @(
    'C:\Program Files (x86)\Windows Kits\11\bin',
    'C:\Program Files (x86)\Windows Kits\10\bin'
  )

  foreach ($sdkRoot in $windowsSdkRoots) {
    if (Test-Path $sdkRoot) {
      $signtoolPath = Get-ChildItem -Path $sdkRoot -Recurse -Filter signtool.exe -ErrorAction SilentlyContinue | Select-Object -First 1
      if ($signtoolPath) {
        return $signtoolPath.FullName
      }
    }
  }

  throw 'signtool.exe not found. Install the Windows SDK or add signtool to PATH.'
}

function Sign-InstallerFile(
  [string]$filePath,
  [string]$signPfxPath,
  [string]$signPfxPasswordValue,
  [string]$timestampUrlValue
) {
  if (-not (Test-Path $filePath)) {
    throw "Cannot sign missing file: $filePath"
  }

  if ([string]::IsNullOrWhiteSpace($signPfxPath)) {
    Write-Host "Signing skipped for $filePath (no -SignPfx provided)." -ForegroundColor Yellow
    return
  }

  $passwordText = $signPfxPasswordValue
  if ([string]::IsNullOrWhiteSpace($passwordText) -and $env:CODESIGN_PFX_PASSWORD) {
    $passwordText = $env:CODESIGN_PFX_PASSWORD
  }

  $signtoolPath = Resolve-SigntoolPath
  $signArguments = @(
    'sign',
    '/fd', 'sha256',
    '/td', 'sha256',
    '/tr', $timestampUrlValue,
    '/f', $signPfxPath
  )
  if (-not [string]::IsNullOrWhiteSpace($passwordText)) {
    $signArguments += @('/p', $passwordText)
  }
  $signArguments += $filePath

  & $signtoolPath @signArguments
  if ($LASTEXITCODE -ne 0) {
    throw "Sign failed for $filePath"
  }
}

$installerRootPath = Split-Path -Parent $MyInvocation.MyCommand.Definition
$repoRootPath = Resolve-Path (Join-Path $installerRootPath '..')
$solutionRootPath = Join-Path $repoRootPath 'tools\GrowNetLab'
$appProjectPath = Join-Path $solutionRootPath 'app\GrowNetLab.App\GrowNetLab.App.csproj'
$versionPropsPath = Join-Path $solutionRootPath 'Directory.Build.props'
$publishDirectoryPath = Join-Path $installerRootPath 'publish'
$artifactDirectoryPath = Join-Path $installerRootPath 'artifacts'
$assetDirectoryPath = Join-Path $installerRootPath 'assets-generated'
$versionText = Read-LabVersion $versionPropsPath
$productVersionText = Get-FourPartVersion $versionText
$msiOutputPath = Join-Path $artifactDirectoryPath 'GrowNetLab.msi'
$bundleOutputPath = Join-Path $artifactDirectoryPath 'GrowNetLabSetup.exe'
$licenseFilePath = Join-Path $assetDirectoryPath 'GrowNetLab-License.rtf'
$bannerFilePath = Join-Path $assetDirectoryPath 'GrowNetLabBanner.bmp'
$dialogFilePath = Join-Path $assetDirectoryPath 'GrowNetLabDialog.bmp'
$splashFilePath = Join-Path $assetDirectoryPath 'GrowNetLabSplash.bmp'

Ensure-Directory $publishDirectoryPath
Ensure-Directory $artifactDirectoryPath
Ensure-Directory $assetDirectoryPath

Write-Info "Publishing GrowNet Lab $versionText"
$publishArguments = @(
  'publish',
  $appProjectPath,
  '-c', $Configuration,
  '-r', $Runtime,
  '-f', $Framework,
  '-o', $publishDirectoryPath,
  "-p:SelfContained=$($SelfContained.ToString().ToLowerInvariant())",
  '-p:PublishSingleFile=false'
)
& dotnet @publishArguments | Out-Host
if ($LASTEXITCODE -ne 0) {
  throw "dotnet publish failed with exit code $LASTEXITCODE"
}

Write-InstallerLicense $licenseFilePath
Write-BrandBitmap $bannerFilePath 493 58 'GrowNet Lab' 'NektronAI research workstation installer'
Write-BrandBitmap $dialogFilePath 493 312 'GrowNet Lab' 'Install the lab app, then point it at a local GrowNet source root on first launch.'
Write-BrandBitmap $splashFilePath 493 312 'GrowNet Lab Setup' 'App-only installer for the WPF lab shell'

$wixProductArguments = @(
  'build',
  '-arch', 'x64',
  (Join-Path $installerRootPath 'Product.wxs'),
  (Join-Path $installerRootPath 'AppFiles.wxs'),
  '-ext', 'WixToolset.UI.wixext',
  '-culture', 'en-us',
  '-d', "PublishDir=$publishDirectoryPath",
  '-d', "ProductVersion=$productVersionText",
  '-d', 'Manufacturer=NektronAI',
  '-d', 'AppExeName=GrowNetLab.App.exe',
  '-d', "WixUIBannerBmp=$bannerFilePath",
  '-d', "WixUIDialogBmp=$dialogFilePath",
  '-o', $msiOutputPath
)

Write-Info "Building MSI"
& wix @wixProductArguments | Out-Host
if ($LASTEXITCODE -ne 0) {
  throw "wix MSI build failed with exit code $LASTEXITCODE"
}

$wixBundleArguments = @(
  'build',
  '-arch', 'x64',
  (Join-Path $installerRootPath 'Bundle.wxs'),
  '-ext', 'WixToolset.BootstrapperApplications.wixext',
  '-d', "ProductMsi=$msiOutputPath",
  '-d', "BundleVersion=$productVersionText",
  '-d', 'BundleManufacturer=NektronAI',
  '-d', "LicenseFile=$licenseFilePath",
  '-d', "SplashFile=$splashFilePath",
  '-o', $bundleOutputPath
)

Write-Info "Building bootstrapper"
& wix @wixBundleArguments | Out-Host
if ($LASTEXITCODE -ne 0) {
  throw "wix bundle build failed with exit code $LASTEXITCODE"
}

Sign-InstallerFile $msiOutputPath $SignPfx $SignPfxPassword $TimestampUrl
Sign-InstallerFile $bundleOutputPath $SignPfx $SignPfxPassword $TimestampUrl

Write-Host 'Installer build complete.' -ForegroundColor Green
Write-Host "MSI : $msiOutputPath"
Write-Host "EXE : $bundleOutputPath"
