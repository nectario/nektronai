#!/usr/bin/env bash
set -euo pipefail

workspace_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$workspace_dir"

build_java_classpath() {
  local classpath_file="target/runtime-classpath.txt"
  local classpath_separator=":"
  case "$(uname -s)" in
    MINGW*|MSYS*|CYGWIN*)
      classpath_separator=";"
      ;;
  esac
  mvn -q -DskipTests compile dependency:build-classpath "-Dmdep.outputFile=${classpath_file}" >/dev/null
  local java_classpath="target/classes"
  if [[ -f "${classpath_file}" ]]; then
    local dependency_classpath
    dependency_classpath="$(tr -d '\r' < "${classpath_file}")"
    if [[ -n "${dependency_classpath}" ]]; then
      java_classpath="${java_classpath}${classpath_separator}${dependency_classpath}"
    fi
  fi
  printf '%s' "${java_classpath}"
}

print_usage() {
  cat <<'EOF'
Usage: ./grownet.sh --lang java|python [runner options]
       ./grownet.sh --help

Preferred entry point: ./grownet.sh
Compatibility path:    ./scripts/grownet.sh

Languages:
  java      implemented
  python    implemented
  mojo      temporal Morse slice implemented via host launcher
  cpp       accepted but not implemented

Shared scenario options:
  --scenario single_neuron|two_layer|image_2d|growth|morse_probe
  --value 0.42
  --ticks 1
  --config path/to/experiment.json
  --input path/to/input_file
  --input-type sequence|tensor|image|audio
  --output path/to/output_file_or_dir
  --mode run|trace|benchmark|interactive

Trace options:
  --trace
  --debug
  --trace-format text|jsonl
  --trace-events tick,layer,neuron,slot,weight,threshold,tract,growth,prune,bus,focus,anchor,morse
    Exact event-name filters are also accepted, for example: threshold.update
  --trace-signal
  --out stdout|path/to/file.log
  --trace-neuron E0
  --trace-layer 0

Benchmark options:
  --benchmark
  --benchmark-format text|jsonl
  --benchmark-warmup 100
  --benchmark-iterations 1000
  --benchmark-repeat 5
  --benchmark-output stdout|path/to/file.log

Interactive options (Python rich, Java Morse session slice with raw-key live mode, Mojo host-managed Morse slice):
  --interactive
  --profile single_scalar|dual_scalar|growth_probe|morse_probe
  --config path/to/experiment.json
  --normalize-inputs normalized|raw
  --interactive-output compact|verbose|jsonl
  --interactive-trace on|off
  --interactive-mode scripted|live|replay
  --tick-ms 50
  --record-schedule path/to/schedule.json
  --replay-schedule path/to/schedule.json
  --jitter-ms 10
  --jitter-pct 0.10
  --jitter-seed 0
  --help

Temporal schedule options:
  --record-schedule path/to/schedule.json
  --replay-schedule path/to/schedule.json
  --jitter-ms 10
  --jitter-pct 0.10
  --jitter-seed 0
EOF
}

selected_lang=""
help_requested=false
interactive_requested=false
config_requested=false
mode_requested=""
input_requested=false
input_type_requested=false
generic_output_requested=false
forwarded_args=()

while (($# > 0)); do
  case "$1" in
    --lang)
      if (($# < 2)); then
        echo "Missing value for --lang" >&2
        exit 2
      fi
      selected_lang="$2"
      forwarded_args+=("$1" "$2")
      shift 2
      ;;
    --lang=*)
      selected_lang="${1#*=}"
      forwarded_args+=("$1")
      shift
      ;;
    --help|-h)
      help_requested=true
      forwarded_args+=("$1")
      shift
      ;;
    --interactive)
      interactive_requested=true
      forwarded_args+=("$1")
      shift
      ;;
    --config)
      if (($# < 2)); then
        echo "Missing value for --config" >&2
        exit 2
      fi
      config_requested=true
      forwarded_args+=("$1" "$2")
      shift 2
      ;;
    --config=*)
      config_requested=true
      forwarded_args+=("$1")
      shift
      ;;
    --input)
      if (($# < 2)); then
        echo "Missing value for --input" >&2
        exit 2
      fi
      input_requested=true
      forwarded_args+=("$1" "$2")
      shift 2
      ;;
    --input=*)
      input_requested=true
      forwarded_args+=("$1")
      shift
      ;;
    --input-type)
      if (($# < 2)); then
        echo "Missing value for --input-type" >&2
        exit 2
      fi
      input_type_requested=true
      forwarded_args+=("$1" "$2")
      shift 2
      ;;
    --input-type=*)
      input_type_requested=true
      forwarded_args+=("$1")
      shift
      ;;
    --output)
      if (($# < 2)); then
        echo "Missing value for --output" >&2
        exit 2
      fi
      generic_output_requested=true
      forwarded_args+=("$1" "$2")
      shift 2
      ;;
    --output=*)
      generic_output_requested=true
      forwarded_args+=("$1")
      shift
      ;;
    --mode)
      if (($# < 2)); then
        echo "Missing value for --mode" >&2
        exit 2
      fi
      mode_requested="$2"
      forwarded_args+=("$1" "$2")
      if [[ "$mode_requested" == "interactive" ]]; then
        interactive_requested=true
      fi
      shift 2
      ;;
    --mode=*)
      mode_requested="${1#*=}"
      if [[ "$mode_requested" == "interactive" ]]; then
        interactive_requested=true
      fi
      forwarded_args+=("$1")
      shift
      ;;
    *)
      forwarded_args+=("$1")
      shift
      ;;
  esac
done

if [[ "$help_requested" == "true" ]]; then
  print_usage
  exit 0
fi

if [[ -z "$selected_lang" ]]; then
  echo "--lang is required. Use --help for usage." >&2
  exit 2
fi

case "$selected_lang" in
  java)
    if [[ "$input_requested" == "true" || "$input_type_requested" == "true" || "$generic_output_requested" == "true" ]]; then
      echo "GrowNet experiment runner: --lang ${selected_lang} supports only the narrow Morse config slice and does not implement --input, --input-type, or --output here." >&2
      exit 2
    fi
    java_classpath="$(build_java_classpath)"
    java -cp "$java_classpath" ai.nektron.grownet.debug.GrowNetTraceMain "${forwarded_args[@]}"
    ;;
  python)
    if [[ "$interactive_requested" == "true" ]]; then
      python src/python/interactive/interactive_main.py "${forwarded_args[@]}"
    else
      python src/python/demos/grownet_trace_main.py "${forwarded_args[@]}"
    fi
    ;;
  mojo)
    python tools/mojo/mojo_morse_launcher.py "${forwarded_args[@]}"
    ;;
  cpp)
    if [[ "$interactive_requested" == "true" ]]; then
      echo "GrowNet interactive runner: --lang ${selected_lang} is not implemented in this repository." >&2
    else
      echo "GrowNet trace runner: --lang ${selected_lang} is not implemented in this repository." >&2
    fi
    exit 2
    ;;
  *)
    echo "Unsupported --lang: ${selected_lang}" >&2
    exit 2
    ;;
esac
