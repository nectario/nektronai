# GrowNet

GrowNet is a research codebase for an event-driven, growth-capable neural architecture built around local slot memory, temporal anchoring, spatial focus, and explicit cross-language experimentation.

The current repository supports:

- Python as the richest experimentation surface
- Java as the core semantic and architectural reference
- Mojo as the performance-oriented Morse and temporal slice
- shared tracing, benchmarking, interactive probing, and temporal schedule replay

## What GrowNet Is

GrowNet is not a conventional fixed-topology neural net.

Core ideas:

- each neuron owns a set of slots rather than a single weight/bias
- slot selection is anchor-relative
- learning happens locally and tick-by-tick
- growth can add slots, neurons, layers, and regions over time
- focus and anchoring are first-class concepts in the Python runtime
- temporal structure is treated as raw signal over ticks, not pre-decoded symbols

## What You Can Do Today

From the repo root, the main entry point is:

```bash
./grownet.sh
```

Current runner modes:

- `trace`: inspect execution and event flow
- `benchmark`: compare runtime behavior across implementations
- `interactive`: manually probe a persistent GrowNet instance
- `run` / config-driven batch execution: execute experiments from JSON config

Recent work on `main` includes:

- benchmark mode in the shared CLI
- Python interactive mode with profiles and config support
- config-driven experiment execution for Python
- Focus & Anchoring V1 in Python
- Morse probe mode across Python, Java, and Mojo
- shared temporal capture / replay / jitter schedule support across Python, Java, and Mojo

## Quick Start

Trace:

```bash
./grownet.sh --lang python --trace --scenario single_neuron --value 0.42
./grownet.sh --lang java --trace --trace-format jsonl --scenario growth --value 0.42
```

Benchmark:

```bash
./grownet.sh --lang python --benchmark --scenario two_layer --benchmark-warmup 25 --benchmark-iterations 250 --benchmark-repeat 3
./grownet.sh --lang java --benchmark --scenario single_neuron --benchmark-warmup 25 --benchmark-iterations 250 --benchmark-repeat 3
```

Interactive:

```bash
./grownet.sh --lang python --interactive
./grownet.sh --lang python --interactive --profile morse_probe
./grownet.sh --lang java --interactive --profile morse_probe
./grownet.sh --lang mojo --interactive --profile morse_probe --interactive-mode replay --replay-schedule experiments/morse_temporal_schedule.json
```

Config-driven execution:

```bash
./grownet.sh --lang python --config experiments/single_scalar_sequence.json
./grownet.sh --lang python --trace --config experiments/morse_raw_schedule.json
./grownet.sh --lang java --config experiments/morse_raw_schedule.json
```

## Temporal Schedules

GrowNet now has a shared temporal schedule format across Python, Java, and Mojo for:

- live timing capture
- schedule recording
- deterministic replay
- deterministic jittered replay
- replay-based parity testing

Example:

```bash
./grownet.sh --lang python --interactive --profile morse_probe --interactive-mode live --record-schedule out/python_capture.json
./grownet.sh --lang java --interactive --profile morse_probe --interactive-mode replay --replay-schedule experiments/morse_temporal_schedule.json
./grownet.sh --lang mojo --benchmark --replay-schedule experiments/morse_temporal_schedule.json --jitter-ms 10 --jitter-seed 7 --benchmark-format jsonl --benchmark-warmup 1 --benchmark-iterations 2 --benchmark-repeat 1
```

Important:

- there is no external Morse classifier in the runner
- there is no dot/dash parser outside GrowNet
- time meaning is still intended to emerge inside the model

## Language Roles

GrowNet uses a dual-reference model:

- Java: semantic and architectural reference
- Python: Pythonic reference and fastest experimentation surface
- Mojo: should track Python closely where practical, with honest current limitations
- C++: follows Java semantics as much as practical

Current high-level language scope:

- Python: fullest runtime, focus/anchoring, experiment runner, rich interactive mode
- Java: strong trace/benchmark support, complete Morse core slice, scripted/live/replay Morse session support
- Mojo: honest temporal Morse core slice through the current launcher surface, including run, benchmark, scripted/live/replay temporal sessions
- C++: present in the repository and intended to follow Java semantics as much as practical, but the shared CLI launcher path is not implemented yet

## Repo Layout

- `src/python/` — Python runtime, interactive runner, experiment runner, focus, tests
- `src/java/` — Java runtime, debug runner, trace, benchmark, Morse session slice
- `src/mojo/` — Mojo runtime support for the current Morse and temporal slice
- `tools/mojo/` — Mojo host launcher and integration plumbing
- `experiments/` — checked-in experiment configs and shared temporal schedule examples
- `docs/` — design, runner, policy, focus, temporal, and contract docs

## Where To Read Next

Start here:

- [`docs/READ_ORDER.md`](docs/READ_ORDER.md)
- [`docs/LANGUAGE_REFERENCE_POLICY.md`](docs/LANGUAGE_REFERENCE_POLICY.md)
- [`docs/CODING_STYLE_MUST_READ.md`](docs/CODING_STYLE_MUST_READ.md)
- [`docs/GOLDEN_RULE.md`](docs/GOLDEN_RULE.md)

Practical runner docs:

- [`docs/TRACE_RUNNER.md`](docs/TRACE_RUNNER.md)
- [`docs/BENCHMARK_RUNNER.md`](docs/BENCHMARK_RUNNER.md)
- [`docs/INTERACTIVE_RUNNER.md`](docs/INTERACTIVE_RUNNER.md)
- [`docs/EXPERIMENT_RUNNER.md`](docs/EXPERIMENT_RUNNER.md)
- [`docs/MORSE_PROBE.md`](docs/MORSE_PROBE.md)
- [`docs/TEMPORAL_SIGNAL_SCHEDULES.md`](docs/TEMPORAL_SIGNAL_SCHEDULES.md)
- [`docs/FOCUS_AND_ANCHORING.md`](docs/FOCUS_AND_ANCHORING.md)

Core semantics:

- [`docs/contracts/grownet.contract.v5.json`](docs/contracts/grownet.contract.v5.json)
- [`docs/GrowNet_Design_Spec_V5.md`](docs/GrowNet_Design_Spec_V5.md)

## Contract Files

The machine-first contract lives under `docs/contracts/`:

- `grownet.contract.v5.json`
- `grownet.contract.v5.canonical.json`
- `grownet.contract.schema.json`
- `CONTRACT_RENDER.md`

These are still authoritative for contract-facing semantics. The top-level README is now the practical project overview rather than the contract landing page.
