# Parity Decision Checklist

When Java and Python traces differ, ask:

1. Is this difference explicitly governed by the contract/spec?
   - If yes, align behavior.

2. Is this difference only trace formatting / serialization?
   - If yes, fix the trace layer, not runtime semantics.

3. Is this difference an allowed language-style difference?
   - If yes, preserve the language-specific implementation.

4. Is this a real runtime bug independent of parity?
   - If yes, fix it as a bugfix PR.

5. Would changing Python here make Mojo inherit a more Java-like implementation unnecessarily?
   - If yes, do not do it without explicit approval.
