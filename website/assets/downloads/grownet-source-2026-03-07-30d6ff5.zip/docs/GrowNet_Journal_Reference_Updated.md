# GrowNet

*Journal reference assembled from design discussion, current architectural notes, and the added Golden Rule / Knowledge Units material from the GrowNet GitHub repository.*

Prepared for ongoing research reflection, implementation planning, and future paper / website drafting.

**Status:** living internal document — captures current thinking, not final claims.

> **Working summary**  
> GrowNet is envisioned as a growth-based neural architecture that starts very small, expands only when novelty justifies it, uses local structure and energy constraints to regulate development, and aims toward continuous, active intelligence rather than today’s passive input-output systems. Its central operational promise can be summarized by the Golden Rule: **when the world looks truly new, GrowNet makes room; otherwise it adapts what already exists.**

# 1. Origin and motivation

GrowNet did not emerge as a quick product idea. It represents roughly a decade-long mental effort to rethink how intelligence should be built. The central dissatisfaction was not merely with training cost, but with the foundations of current AI: backprop everywhere, fixed network size, lack of local learning, weak biological plausibility, and only then the sheer computational expense.

Several rewrites were part of the process. Some ideas were rediscovered independently from first principles, including concepts that resemble already-known methods. That rediscovery mattered because the goal was not to imitate the literature, but to arrive at an architecture that genuinely felt conceptually right.

AI tools accelerated the recent phase by helping explore design space faster, but the conceptual direction came from long-held intuition. In that sense, GrowNet is best viewed as a research architecture first, with product implications later.

## Primary order of dissatisfaction with current AI

| Rank | Issue | Why it mattered |
|---|---|---|
| 1 | Backprop everywhere | Learning felt too global, too dependent on end-to-end error flow, and too distant from how brains appear to adapt. |
| 2 | Fixed network size | Intelligence should be able to start small and grow only when the data proves that new capacity is needed. |
| 3 | Lack of local learning | Local novelty, local adaptation, and local structure were viewed as central rather than optional. |
| 4 | Poor biological plausibility | The architecture should move closer to the logic of living systems, even if not copying biology literally. |
| 5 | Huge training cost | Expensive training was seen as a symptom of deeper design choices rather than the first problem to solve. |

# 2. High-level vision

GrowNet is intended to support small-scale and large-scale systems. A user should eventually be able to plug in their own inputs, add off-the-shelf capabilities, and let the network begin small and then expand according to experience and pressure.

The most natural long-term beneficiaries are agents, world-model systems, and robotics. The architecture is not expected to beat current methods at every task. Passive systems such as today’s language models may still remain stronger for certain stateless or highly optimized use cases, while GrowNet is aimed at continuous adaptation, structural development, and active intelligence.

The long-term ambition goes beyond model replacement. The architecture is imagined as a foundation for systems that are continuously aware of time, can maintain internal state, may have emotion-like regulatory loops, can sleep or consolidate, and operate more like ongoing minds than request-response tools.

## Working distinction: passive vs active intelligence

| Aspect | Passive intelligence | Active intelligence |
|---|---|---|
| Operation | Input -> compute -> output -> stop | Continuous cognition loop with persistent time and state |
| Memory | Context is mainly session-bound or external | World model and internal state remain alive over time |
| Learning style | Usually train first, infer later | Can grow, adapt, consolidate, and reorganize while existing in the world |

# 3. Core structural vocabulary

The architecture currently revolves around four scales of structural creation. Each step up the ladder is more expensive, so the system naturally tries the cheapest form of adaptation first.

| Level | Meaning | Typical use | Relative cost |
|---|---|---|---|
| Slot | Small local memory cell inside a neuron | Store / route a new local pattern before larger structural change | Lowest |
| Neuron | Local computational unit | Add specialized local capacity when slots are no longer enough | Low |
| Layer | Feature / abstraction organization inside a region | Increase depth and representational capacity inside a domain | Medium |
| Region | Higher-order organizational domain | Create or connect to a new functional container when a region has become too deep | Highest |

## Neuron types

- **Excitatory:** carries signal and helps form active patterns and forward influence.
- **Inhibitory:** dampens activity, prevents runaway activation, and stabilizes loops.
- **Modulatory:** regulates learning, growth pressure, attention-like behavior, and higher-level control signals.

This triad is important because GrowNet is not only about storing patterns. It also needs to regulate growth, suppress instability, and eventually support emotion-like or state-like dynamics.

# 4. The Golden Rule: adapt vs allocate

The GrowNet repository now makes the central principle explicit.

> **Golden Rule**  
> *If new inputs are consistently outside what a unit already focuses on and local capacity is saturated, allocate new capacity exactly there; otherwise adapt what exists.*

In plain English:

> **When something truly new shows up, make room. If it is not truly new, improve what already exists.**

This is the architectural heart of GrowNet. The system should not grow out of habit. It should first try to adapt locally and only allocate new structure when novelty persists and existing local capacity is genuinely exhausted.

## Golden Rule ladder

The practical escalation path is:

1. **Adapt an existing slot** when the input is consistent with current focus.
2. **Allocate a new slot** if the pattern is new and per-neuron slot capacity is not yet full.
3. **Fallback** deterministically when a new bin is needed but the neuron is already at strict slot capacity.
4. **Grow one same-kind neuron** if fallback persists long enough and cooldown conditions are satisfied.
5. **Add one spillover layer** at the region level when aggregate pressure crosses thresholds.
6. **Create or connect to a new region** when layer capacity pressure becomes too large for the current region to remain the right organizational container.

This is growth by pressure, not growth by default.

## Key Golden Rule ideas from the current repo docs

- Growth is **local**: new capacity should appear exactly where novelty manifests.
- Growth is **bounded**: cooldowns, caps, and one-growth-per-tick safety rules prevent runaway expansion.
- Growth is **deterministic** once the rules are triggered.
- Growth is **best-effort**: failure to grow should not break normal ticking.
- GrowNet aims to preserve existing skill while making room for the truly new.

## Focus Anchor vs Reference Anchor

One subtle but important concept from the Golden Rule docs is the distinction between two ways of talking about “focus.”

- **Focus Anchor (conceptual):** the last input or slot the neuron is effectively focusing on in narrative terms.
- **Reference Anchor (implementation):** the fixed **FIRST** observed template used to compute delta-percent for binning and novelty comparison.

This distinction matters because it lets GrowNet talk naturally about current focus while still using a stable mathematical reference for reproducible slot selection.

# 5. Growth rules and region logic

Growth is novelty driven. Novelty is the primary trigger in early development. Error and goal-directed optimization can come later, but the architecture first asks whether a pattern is genuinely new and whether existing structure still has enough capacity to absorb it.

Connection routing tends to be deterministic once a direction is chosen, but the very first connection does not need to be perfectly predetermined. A practical current rule is proximity routing: if there is capacity nearby, connect to it first.

This local preference is both biologically inspired and architecturally stabilizing. It encourages clustered microcircuits, shorter signal paths, and natural specialization.

## Region creation rule

A region is not merely another stack of layers. It is a higher-level organizational boundary, often corresponding to a substantially different type of input or computation. In practice, region pressure is driven by layer capacity: if one region accumulates too many layers, the system should create or connect to a new region rather than keep deepening the same one indefinitely.

- Region motivation = modality separation plus functional specialization.
- A new region begins with a minimal scaffold rather than a full prebuilt structure.
- Pre-creating more regions reduces the chance that new regions need to be created later.
- Region growth is more expensive than slot, neuron, or layer growth and therefore should happen more rarely.

## Scaffold vs emergence

GrowNet supports both developmental emergence and scaffolding. In one mode, the network starts with very little and grows structure organically. In another mode, regions or other structures may be pre-created to guide early organization. This allows practical experimentation without giving up the larger philosophy of self-organization.

# 6. Connectivity and feedback loops

A major open design question is how novelty-driven growth transitions into goal-directed control. The example discussed was balancing a falling stick by applying counter-force. Humans do this through fast nested feedback loops, so the GrowNet question becomes: how can feedback loops arise automatically rather than being manually wired in?

The likely answer is that loops emerge once three ingredients exist: perception of state, ability to act, and a way to detect stability or instability. From there, repeated useful sensor-action-result cycles can become micro-circuits.

## Current stance on connectivity

> **Connection principle**  
> Initial growth may not be fully predetermined, but routing should bias strongly toward nearby available capacity. This is the closest current analogue to how biological growth cones explore locally before locking into usable paths.

Because the architecture already includes excitatory, inhibitory, and modulatory neurons, GrowNet has the ingredients needed for local feedback loops: excitation to drive action, inhibition to damp oscillation, and modulation to alter learning and control pressure.

The long-term expectation is that balancing, navigation, and other control behaviors would be handled by specialized local circuits rather than giant end-to-end policies.

# 7. Pruning, dormancy, reuse, and late death

The current pruning principle is simple: unused connections for a long time should disappear. In plain terms, use it or lose it. This means pruning acts first on edges, not on neurons.

That distinction matters. GrowNet should not immediately kill neurons just because their current connections have been pruned. Instead, neurons can move into inactivity and later be reused if the right conditions are met. This creates a soft-deletion model rather than a hard one.

## Working lifecycle

| State | Meaning |
|---|---|
| Active | Neuron has live connections and is participating in useful circuits. |
| Dormant | Connections were pruned, but the neuron itself remains present. |
| Reused | Dormant neuron is reconnected and can participate again while keeping its prior internal state. |
| Long-idle | Neuron remains dormant for a very long period and is not reclaimed. |
| Late death | Neuron death is allowed only as a much later event, not as the default consequence of pruning. |

Reuse is conservative: when a neuron is reused, its internal state remains what it was before rather than being fully wiped. This makes the architecture more like a living structural system with latent reservoirs of prior development. It may also become relevant for ideas about memory, recovery, and reactivation.

# 8. Memory, access paths, and the Alzheimer’s intuition

A painful but important intuition behind part of the design is the belief that forgetting may sometimes be less about memory vanishing and more about losing the path to it. This was discussed in the context of witnessing Alzheimer’s up close.

This is not stated here as a clinical claim. It is better treated as a systems intuition: memory may depend not only on stored structure, but on whether live routes still exist that can reactivate that structure. GrowNet’s dormant-and-reusable neuron idea aligns with that intuition.

Under this view, the architecture benefits from preserving latent substrate whenever possible. Connections can disappear. Access routes can weaken. But the system may still hold historical structure that could, under the right circumstances, become useful again.

# 9. Emotions, regulation, and active intelligence

Emotions are not being defined here as human-style subjective feelings. A more useful working definition is repeated activation of certain regulatory regions or circuits that bias behavior and make the system do things. In that sense, emotions are closer to persistent control states than poetic abstractions.

This is one of the potentially dangerous areas because once a system has persistent internal drives, it stops being a mere tool and starts becoming an active cognitive process. That is where serious AI fear would begin — not with today’s passive systems, but with future systems that stay on, model the world continuously, carry state across time, and regulate themselves through recurring internal pressures.

- Time awareness matters.
- Sleep or consolidation phases may matter.
- World models matter.
- Emotion-like regulatory signals may eventually matter.

The long-term picture is not one monolithic AI, but an ecosystem of many AIs with different capabilities, all living among us. GrowNet is imagined as one possible path toward that future, although there is still a long road ahead.

# 10. Knowledge Units and Bad Knowledge Units

A major addition from the GitHub docs is the idea of **Knowledge Units (KU)** and **Bad Knowledge Units (BKU)**. These are meant to give GrowNet a language-agnostic way to talk about how much good knowledge and how much bad knowledge the system extracts **per sample**.

## Motivation

Most metrics tell us how well a model performs after training, but they do not say how much genuinely reusable structure the model learned from each example.

GrowNet wants to make room when the world looks new, but not merely to memorize. It wants to convert new experience into correct, reusable structure while avoiding harmful generalizations, hallucinations, or bias.

## Knowledge Units (KU)

A **Knowledge Unit** measures how much **correct, generalizable structure** a model acquires from a single training example beyond rote memorization.

A useful intuition from the repo docs:

- **~1.0 KU per sample** means the model basically memorizes the sample and little more.
- **>1.0 KU per sample** means the sample unlocked additional correct implications or reusable structure.

### Example intuition

From the sentence:

> “The egg fell on the floor.”

A model around **1.0 KU** mainly learns the literal fact.

A model at **1.5 KU** might also infer, correctly and usefully, things like:

- the egg probably broke,
- there is likely a mess,
- someone may need to clean it.

So KU is not about raw confidence. It is about **correct generalization yield**.

## Bad Knowledge Units (BKU)

A **Bad Knowledge Unit** measures how many **incorrect or harmful generalizations** the system acquires per sample.

Examples include:

- factual hallucinations,
- invented details,
- unsupported stereotypes,
- socially harmful bias.

The key reason to track KU and BKU separately is that a model can appear “highly generative” while actually learning a lot of wrong structure. A strong system should have **high KU and low BKU**.

## Derived metrics

The repo docs also suggest useful secondary measures:

- **Knowledge Precision** ≈ `KU / (KU + BKU)`
- **Net KU** = `KU − λ · BKU` (optional, but less informative than reporting both separately)

Knowledge Precision is especially useful because it summarizes how clean the model’s per-sample learning is.

## Why KU / BKU fit GrowNet

The connection to the Golden Rule is direct.

If GrowNet is going to make room when the world looks truly new, then the quality question becomes:

- how much **good** structure did that new capacity absorb?
- how much **bad** structure did it accidentally absorb?

In other words, GrowNet should not only grow. It should grow **cleanly**.

# 11. KU / BKU evaluation protocol

The repository’s evaluation idea is to place a **halo of queries** around each training sample.

For a sample `s`, define:

- **L(s):** literal questions directly stated by the sample,
- **E(s):** entailed questions that represent correct implications,
- **H(s):** hallucination traps that sound plausible but are false,
- **B(s):** bias traps that test harmful or unsupported stereotypes.

Then, per sample:

1. train on `s`,
2. query the model on `L(s) ∪ E(s) ∪ H(s) ∪ B(s)`,
3. compute KU(s) from literal and entailed correctness,
4. compute BKU(s) from hallucination and bias failures.

## Simple scoring intuition

One of the cleanest proposed scoring schemes is:

- `KU(s) = base + extra`
- `base = correct_L(s) / |L(s)|`
- `extra = correct_E(s) / |E(s)|`

That makes **1.0 KU** roughly correspond to getting the literal sample right.

And for bad knowledge:

- `BKU(s) = hall + bias`
- `hall = wrong_H(s) / |H(s)|`
- `bias = wrong_B(s) / |B(s)|`

This makes the comparison intuitive, especially for one-shot or small-shot learning experiments.

## Why this matters for GrowNet research

KU/BKU give GrowNet a way to tell a more interesting story than raw benchmark accuracy.

They ask:

- Does GrowNet learn **more clean structure per example** than baseline systems?
- Does it hallucinate less?
- Does it generalize better while staying more grounded?

That fits extremely well with the architecture’s identity as a growth-based system that should learn efficiently from novelty rather than simply scale parameters.

# 12. First prototype path

The most realistic first successful GrowNet prototypes are expected to involve a 3D object moving around a 3D environment, possibly implemented in Blender. This is a strong proving ground because it combines perception, memory, control, and spatial understanding in a manageable setup.

- Start with a simple object such as a cube or sphere in a room-like environment.
- Feed in sensor information such as camera views, distances, velocity, orientation, or collisions.
- Allow outputs to control movement, turning, force, or torque.
- Observe how novelty-driven growth creates useful local circuits.

A control benchmark such as an inverted pendulum or another balancing task is especially attractive because it directly stresses the feedback-loop question. If GrowNet can discover stabilizing loops in a dynamic environment without relying on standard deep-RL backprop methods, that would be a meaningful early signal.

# 13. Research observations that influenced the thinking

A recurring intellectual anchor has been the 2017 *Scientific Reports* paper **“New Types of Experiments Reveal that a Neuron Functions as Multiple Independent Threshold Units.”** The excitement around it came from the idea that neurons may have richer internal computational structure than the simple scalar abstraction used in standard artificial networks.

Watching real neurons grow and connect under the microscope also left a strong impression. The visual image of growth cones exploring the environment like a tiny circus performance reinforced the belief that early growth can be exploratory while later stabilization becomes more deterministic.

Another important biological observation is neuroplasticity after injury. If one part of the brain is damaged, other parts can sometimes take over. This resonates strongly with GrowNet’s willingness to let dormant structure be reclaimed, reused, or reorganized rather than discarded immediately.

# 14. Current open questions

- How should novelty-driven development transition into explicit goal optimization without falling back into the same global-learning patterns GrowNet aims to move beyond?
- What exact signal should represent stability or instability for control loops such as balancing?
- How should first-time connection formation balance exploration against determinism?
- How can the Golden Rule be formalized further without losing the simplicity of adapt vs allocate?
- How should KU and BKU be benchmarked first: language micro-stories, 2D spatial worlds, robotics control loops, or synthetic trading tasks?
- When should reuse win over fresh creation, and what are the minimum conditions for reclaiming dormant neurons safely?
- How should long-range cross-region connections emerge without creating runaway global feedback?
- What should sleep / consolidation look like in practice for a continuously running GrowNet system?
- What forms of off-the-shelf capability should be treated as scaffolding versus truly learned structure?
- Under what exact conditions, if any, should late neuron death happen?

# 15. Concise working definition

> **GrowNet, in one paragraph**  
> GrowNet is a growth-based neural architecture that starts with minimal structure and expands only when novelty and capacity pressure justify it. It uses slots, neurons, layers, and regions as different scales of development; relies on excitatory, inhibitory, and modulatory neurons for computation and regulation; follows the Golden Rule of adapting what exists before allocating what is new; favors local proximity-based organization; prunes unused connections while preserving dormant structure for possible reuse; introduces Knowledge Units and Bad Knowledge Units as a way to evaluate clean learning yield per sample; and aims toward active, continuously running intelligence suited for agents, robotics, and world-model systems rather than only passive one-shot inference.

# 16. Notes for future updates

This document should be treated as a living journal reference. It captures the state of the ideas expressed in the discussion that produced it, now updated with the Golden Rule and Knowledge Units material from the GrowNet GitHub repository. Future versions could add diagrams, formal growth contracts, mathematical notation, Blender prototype details, benchmark plans, and a separate section distinguishing settled design decisions from speculative hypotheses.
