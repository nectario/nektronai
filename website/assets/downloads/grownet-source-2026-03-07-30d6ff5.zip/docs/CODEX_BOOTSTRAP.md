# Codex Bootstrap Instructions

If you are an automated coding agent working on GrowNet:

1. Start with docs/READ_ORDER.md
2. Follow the canonical document list defined there.
3. Ignore the following directories for implementation decisions:

- docs/archive/
- docs/generated_reports/

These directories contain historical and diagnostic information only.

## Important parity rule for coding agents

Do not force Python internals to mimic Java unless the difference is clearly contract-level or semantically required.

Python is the Pythonic reference implementation.
Mojo should follow Python closely.

When parity fixtures fail, classify the difference as one of:
- contract-level semantic drift
- trace serialization mismatch
- allowed language-style difference
- genuine bug

Do not change Python runtime semantics solely to make fixtures match Java unless explicitly instructed.
