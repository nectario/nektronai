# Documentation Archive

This directory contains historical GrowNet documentation.

These documents are preserved for research and development history but **must not be treated as authoritative specifications**.

For current implementation guidance, follow the documents listed in:

docs/READ_ORDER.md
