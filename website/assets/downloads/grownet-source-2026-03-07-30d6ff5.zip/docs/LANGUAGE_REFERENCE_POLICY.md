# GrowNet Language Reference Policy

GrowNet uses a dual-reference model.

## Java

Java is the core semantic and architectural reference implementation.

Java defines:
- contract-level behavior
- core architectural intent
- semantic anchor for cross-language parity
- the reference C++ should follow as much as practical

## Python

Python is the Python-language-style reference implementation.

Python defines:
- Pythonic structure
- readability-first implementation style
- explicit code over clever one-liners
- the reference Mojo should follow almost one-to-one

## Mojo

Mojo should match Python closely, adjusted only for language constructs such as:
- `def` vs `fn`
- `class` vs `struct`

Mojo should preserve Python structure, readability, and explicitness wherever practical.

## C++

C++ should follow Java semantics as much as practical while remaining idiomatic C++.

## Parity Rule

Cross-language parity exists to validate:
- contract-level semantics
- deterministic behavior where defined
- canonical trace schema
- canonical signal-id format
- canonical scenario construction

Cross-language parity does NOT require all languages to share identical internal implementation details when that would violate the intended language-reference model.
