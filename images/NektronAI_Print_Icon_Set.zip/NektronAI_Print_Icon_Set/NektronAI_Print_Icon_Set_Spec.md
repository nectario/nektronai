# NektronAI Print Icon Set

This add-on icon follows the current Ribbon Premium Precision Polish Dark Surface Final large-tier language.

## Concept
A premium desktop **printer** silhouette with:
- rear feed paper sheet
- structured control panel
- front output page
- small premium status nodes

## Size intent
- **16 / 20**: simplified, instant printer read
- **24 / 32**: balanced command-bar detail
- **48**: richer ribbon presentation
- **64**: hero-grade finish with more confident material separation

## Export model
- `svg/` = standard master for light/neutral use
- `svg_dark_export/` = dark-surface tuned master with stronger contrast
